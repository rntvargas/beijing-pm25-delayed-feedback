# Frozen analysis code v0.3.0

Renato Quispe Vargas, Universidad Nacional del Altiplano.
Code DOI: https://doi.org/10.5281/zenodo.23171630
Repository: https://github.com/rntvargas/beijing-pm25-delayed-feedback
Related research release: https://github.com/rntvargas/beijing-pm25-delayed-feedback/releases/tag/v0.3.0

This archive contains original Python/R analysis code, environment requirements and methodological documentation, under MIT. It excludes the manuscript, Springer template, external data, models and predictions. Obtain those from the research release, or regenerate from the UCI dataset using download_data.py (source CC BY 4.0; DOI 10.24432/C5RK5G). This code DOI is not an article DOI.

Python 3.12.14 and R 4.5.2 were used. From a clean extraction:

    python -m pip install -r outputs/03_experimento/requirements.txt
    python download_data.py
    python outputs/02_datos_estudio/preparar_datos.py
    python outputs/03_experimento/experimento.py --stage development
    python outputs/03_experimento/experimento.py --stage final
    python outputs/05_revision/revision.py
    python outputs/05_revision/segundo_periodo.py
    python outputs/05_revision/diagnosticos.py
    python outputs/05_revision/bootstrap_exploratorio.py
    python outputs/05_revision/verificar_cqr.py
    python outputs/05_revision/verificar_tiempos.py
    Rscript outputs/05_revision/verificar_revision.R outputs/05_revision

See METHOD_SPECIFICATION.md for exact CQR and the ACI-inspired daily delayed-feedback heuristic (ADH). Historical machine keys remain unchanged. Local prespecification, post-review exploration and sensitivity analyses are distinguished. No independent external confirmation, universal coverage guarantee, new algorithm, or journal acceptance is claimed. AI assisted implementation and drafting; author review remains required. SHA256.json identifies every archived source file.
