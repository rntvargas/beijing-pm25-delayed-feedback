# Estado de la revisión

Autor: Renato Quispe Vargas, Universidad Nacional del Altiplano.

Versión exploratoria en formato Springer Nature, con 31 referencias con DOI y distinción explícita de los cinco DOI de preprint. No se afirma aceptación ni suficiencia para una revista Q1.

Se conservaron los resultados iniciales y se añadieron CQR, cuantiles sin calibrar, una variante ACI con actualización diaria y feedback demorado, ajuste del predictor por demora, calibración por estación, bandas bootstrap, sensibilidad de latencias heterogéneas, auditorías de ausencia de respuestas y un segundo periodo de Beijing. Este último no es una validación externa independiente.

A 72 h y 90% nominal: calibración móvil original, cobertura 88,32%, score 328,01; CQR, 88,91% y 258,40; ACI modificada, 89,78% y 317,48. La comparación CQR incluye cambios de entrenamiento y modelado. Las mejoras originales no son robustas a todas las longitudes de bloque.

R reprodujo las 68 filas de métricas de la ampliación. La auditoría temporal reconstruyó 90 cuantiles y verificó invariancia frente a perturbaciones de resultados futuros. Las tablas, predicciones y registros de llegada están en outputs/05_revision.

Repositorio: https://github.com/rntvargas/beijing-pm25-delayed-feedback

Pendientes antes del envío: revisión y aprobación del autor, correspondencia, contribuciones, financiación, conflictos, selección de revista . La réplica externa sigue pendiente.

## Revisión v0.3.0

CQR formalizado y reconstruido para 10 configuraciones; ACI adaptado se denomina heurística ADH inspirada en ACI. Se añadieron 267 filas de contrastes con bootstrap de 10000 réplicas y bloques 7/14/28 días, y separación visual P/E/S. P significa preespecificación local, no confirmación independiente. Código congelado en Zenodo: https://doi.org/10.5281/zenodo.23171630 . Este DOI corresponde al código, no al artículo.


## Revisión editorial v0.3.1

PDF: 24 páginas y 31 referencias con DOI. Véase `outputs/05_revision/RESPUESTA_REVISION_V031.md` para las correcciones y `DECLARACIONES_PENDIENTES.md` para los datos del autor pendientes. Auditoría: 101012 respuestas comunes, 20 modelos cuantílicos, 10 configuraciones. Código científico y resultados originales conservados. Publicación: https://github.com/rntvargas/beijing-pm25-delayed-feedback/releases/tag/v0.3.1. DOI del código v0.3.0: https://doi.org/10.5281/zenodo.23171630; no incluye datos, modelos ni manuscrito.
