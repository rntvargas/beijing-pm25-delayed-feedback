# Estado de la revisión

Autor: Renato Quispe Vargas, Universidad Nacional del Altiplano.

Versión exploratoria en formato Springer Nature, con 31 referencias con DOI y distinción explícita de los cinco DOI de preprint. No se afirma aceptación ni suficiencia para una revista Q1.

Se conservaron los resultados iniciales y se añadieron CQR, cuantiles sin calibrar, una variante ACI con actualización diaria y feedback demorado, ajuste del predictor por demora, calibración por estación, bandas bootstrap, sensibilidad de latencias heterogéneas, auditorías de ausencia de respuestas y un segundo periodo de Beijing. Este último no es una validación externa independiente.

A 72 h y 90% nominal: calibración móvil original, cobertura 88,32%, score 328,01; CQR, 88,91% y 258,40; ACI modificada, 89,78% y 317,48. La comparación CQR incluye cambios de entrenamiento y modelado. Las mejoras originales no son robustas a todas las longitudes de bloque.

R reprodujo las 68 filas de métricas de la ampliación. La auditoría temporal reconstruyó 90 cuantiles y verificó invariancia frente a perturbaciones de resultados futuros. Las tablas, predicciones y registros de llegada están en outputs/05_revision.

Repositorio: https://github.com/rntvargas/beijing-pm25-delayed-feedback

Pendientes antes del envío: revisión y aprobación del autor, correspondencia, contribuciones, financiación, conflictos, selección de revista y, si se exige, DOI archivístico. La réplica externa sigue pendiente.
