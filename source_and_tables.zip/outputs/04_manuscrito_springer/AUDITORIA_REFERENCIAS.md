# Auditoría de referencias de la versión revisada

31 referencias citadas: 25 registros Crossref (23 artículos y 2 libros), cinco trabajos de congreso con DOI del preprint correspondiente y un conjunto de datos UCI. En los cinco trabajos de congreso se distingue expresamente el DOI arXiv del enlace de las actas; no se inventó un DOI editorial.

Los registros recuperados permiten cotejar identidad bibliográfica; esto no equivale a lectura exhaustiva de todos los textos completos. Las dos revisiones generales se sustituyeron por Vasseur y Aznarte (2021) y Li et al. (2022). El trabajo de Zhou et al. figura con año de volumen impreso 2026; su publicación electrónica es de 2025. La auditoría se actualizó el 5 de octubre de 2026 a partir de los registros guardados.

| Clave | Año | Título | DOI |
|---|---|---|---|
| vovk2005 | 2005 | Algorithmic Learning in a Random World | [10.1007/b106715](https://doi.org/10.1007/b106715) |
| angelopoulos2023 | 2023 | Conformal Prediction: A Gentle Introduction | [10.1561/2200000101](https://doi.org/10.1561/2200000101) |
| lei2018 | 2018 | Distribution-Free Predictive Inference for Regression | [10.1080/01621459.2017.1307116](https://doi.org/10.1080/01621459.2017.1307116) |
| barber2023 | 2023 | Conformal prediction beyond exchangeability | [10.1214/23-aos2276](https://doi.org/10.1214/23-aos2276) |
| barber2021 | 2021 | Predictive inference with the jackknife+ | [10.1214/20-aos1965](https://doi.org/10.1214/20-aos1965) |
| bergmeir2018 | 2018 | A note on the validity of cross-validation for evaluating autoregressive time series prediction | [10.1016/j.csda.2017.11.003](https://doi.org/10.1016/j.csda.2017.11.003) |
| roberts2017 | 2017 | Cross-validation strategies for data with temporal, spatial, hierarchical, or phylogenetic structure | [10.1111/ecog.02881](https://doi.org/10.1111/ecog.02881) |
| tashman2000 | 2000 | Out-of-sample tests of forecasting accuracy: an analysis and review | [10.1016/s0169-2070(00)00065-0](https://doi.org/10.1016/s0169-2070(00)00065-0) |
| varma2006 | 2006 | Bias in error estimation when using cross-validation for model selection | [10.1186/1471-2105-7-91](https://doi.org/10.1186/1471-2105-7-91) |
| kapoor2023 | 2023 | Leakage and the reproducibility crisis in machine-learning-based science | [10.1016/j.patter.2023.100804](https://doi.org/10.1016/j.patter.2023.100804) |
| kunsch1989 | 1989 | The Jackknife and the Bootstrap for General Stationary Observations | [10.1214/aos/1176347265](https://doi.org/10.1214/aos/1176347265) |
| politis1994 | 1994 | The Stationary Bootstrap | [10.1080/01621459.1994.10476870](https://doi.org/10.1080/01621459.1994.10476870) |
| lahiri2003 | 2003 | Resampling Methods for Dependent Data | [10.1007/978-1-4757-3803-2](https://doi.org/10.1007/978-1-4757-3803-2) |
| friedman2001 | 2001 | Greedy function approximation: A gradient boosting machine. | [10.1214/aos/1013203451](https://doi.org/10.1214/aos/1013203451) |
| hoerl1970 | 1970 | Ridge Regression: Biased Estimation for Nonorthogonal Problems | [10.1080/00401706.1970.10488634](https://doi.org/10.1080/00401706.1970.10488634) |
| koenker1978 | 1978 | Regression Quantiles | [10.2307/1913643](https://doi.org/10.2307/1913643) |
| gneitingcal2007 | 2007 | Probabilistic Forecasts, Calibration and Sharpness | [10.1111/j.1467-9868.2007.00587.x](https://doi.org/10.1111/j.1467-9868.2007.00587.x) |
| gneiting2011 | 2011 | Comparing Density Forecasts Using Threshold- and Quantile-Weighted Scoring Rules | [10.1198/jbes.2010.08110](https://doi.org/10.1198/jbes.2010.08110) |
| hyndman2006 | 2006 | Another look at measures of forecast accuracy | [10.1016/j.ijforecast.2006.03.001](https://doi.org/10.1016/j.ijforecast.2006.03.001) |
| rubin1976 | 1976 | Inference and missing data | [10.1093/biomet/63.3.581](https://doi.org/10.1093/biomet/63.3.581) |
| zhang2017 | 2017 | Cautionary tales on air-quality improvement in Beijing | [10.1098/rspa.2017.0457](https://doi.org/10.1098/rspa.2017.0457) |
| gneiting2007 | 2007 | Strictly Proper Scoring Rules, Prediction, and Estimation | [10.1198/016214506000001437](https://doi.org/10.1198/016214506000001437) |
| cpsurvey2025 | 2026 | Conformal Prediction: A Data Perspective | [10.1145/3736575](https://doi.org/10.1145/3736575) |
| chen2017 | 2017 | Beijing Multi-Site Air Quality | [10.24432/c5rk5g](https://doi.org/10.24432/c5rk5g) |
| gibbs2021 | 2021 | Adaptive Conformal Inference Under Distribution Shift | [10.48550/arxiv.2106.00170](https://doi.org/10.48550/arxiv.2106.00170) |
| zaffran2022 | 2022 | Adaptive Conformal Predictions for Time Series | [10.48550/arxiv.2202.07282](https://doi.org/10.48550/arxiv.2202.07282) |
| xu2023 | 2023 | Sequential Predictive Conformal Inference for Time Series | [10.48550/arxiv.2212.03463](https://doi.org/10.48550/arxiv.2212.03463) |
| zaffran2023 | 2023 | Conformal Prediction with Missing Values | [10.48550/arxiv.2306.02732](https://doi.org/10.48550/arxiv.2306.02732) |
| romano2019 | 2019 | Conformalized Quantile Regression | [10.48550/arxiv.1905.03222](https://doi.org/10.48550/arxiv.1905.03222) |
| vasseur2021 | 2021 | Comparing quantile regression methods for probabilistic forecasting of {NO2} pollution levels | [10.1038/s41598-021-90063-3](https://doi.org/10.1038/s41598-021-90063-3) |
| li2022 | 2022 | Multi-step-ahead prediction interval for locally stationary time series with application to air pollutant concentration data | [10.1002/sta4.411](https://doi.org/10.1002/sta4.411) |
