"""Auditoria y preparacion causal de UCI 501. No ajusta modelos.
Uso: python preparar_datos.py
El paquete incluye raw/uci501.zip; salidas en data/, tables/ y figures/.
"""
from pathlib import Path
import argparse
import hashlib
import io
import json
import platform
import os
import tempfile
import zipfile
from datetime import datetime, timezone
import numpy as np
import pandas as pd
os.environ.setdefault('MPLCONFIGDIR', str(Path(tempfile.gettempdir())/'codex-paper-uci501-mpl'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

HERE = Path(__file__).resolve().parent
ap = argparse.ArgumentParser()
ap.add_argument('--source', type=Path, default=HERE/'raw/uci501.zip')
ap.add_argument('--out', type=Path, default=HERE)
args = ap.parse_args()
out = args.out
for folder in ['data','tables','figures']:
    (out/folder).mkdir(parents=True, exist_ok=True)
EXPECTED = 'b04da438b2f331ac0ffd45aebdfec0d20d2367feb5f6948c4b1f7ce1191e33c4'
sha = hashlib.sha256(args.source.read_bytes()).hexdigest()
assert sha == EXPECTED, 'El archivo de entrada no coincide con la version auditada.'
with zipfile.ZipFile(args.source) as z:
    with zipfile.ZipFile(io.BytesIO(z.read('PRSA2017_Data_20130301-20170228.zip'))) as inner:
        files = sorted(n for n in inner.namelist() if '/PRSA_Data_' in n and n.endswith('.csv'))
        assert len(files)==12
        df = pd.concat([pd.read_csv(inner.open(n)) for n in files], ignore_index=True)
original_columns = df.columns.tolist()
df['datetime'] = pd.to_datetime(df[['year','month','day','hour']],errors='raise')
df = df.sort_values(['station','datetime']).reset_index(drop=True)
assert len(df)==420768 and df.station.nunique()==12
assert not df.duplicated(['station','datetime']).any()
assert df.groupby('station').datetime.diff().dropna().eq(pd.Timedelta(hours=1)).all()
split1, split2, end = map(pd.Timestamp, ['2015-03-01','2016-03-01','2017-03-01'])
df['period'] = np.select([df.datetime < split1, df.datetime < split2], ['development','calibration'],default='test')
pollutants = ['PM2.5','PM10','SO2','NO2','CO','O3']
meteo = ['TEMP','PRES','DEWP','RAIN','wd','WSPM']
variables = pollutants+meteo
for c in variables:
    df[c+'_missing'] = df[c].isna().astype('int8')
assert all(df[c].dropna().ge(0).all() for c in pollutants)
df.to_csv(out/'data/panel_preservado.csv.gz',index=False,na_rep='NA',compression={'method':'gzip','mtime':0})

# Ausencias: conteos y episodios. No se atribuye una causa instrumental.
missing = pd.DataFrame({'variable':variables,
    'missing_n':[int(df[c].isna().sum()) for c in variables],
    'missing_pct':[df[c].isna().mean()*100 for c in variables]})
missing.to_csv(out/'tables/ausencias_por_variable.csv',index=False)
episode_rows = []
for station,g in df.groupby('station',sort=True):
    mask = g['PM2.5'].isna()
    run = mask.ne(mask.shift()).cumsum()
    for _,b in g.loc[mask].groupby(run[mask]):
        episode_rows.append({'station':station,'start':b.datetime.min(),'end':b.datetime.max(),
                             'hours':len(b),'start_period':b.period.iloc[0],
                             'crosses_period':b.period.nunique()>1})
episodes = pd.DataFrame(episode_rows).sort_values(['hours','station'],ascending=[False,True])
assert episodes.hours.sum()==df['PM2.5'].isna().sum()
episodes.to_csv(out/'tables/episodios_ausencia_pm25.csv',index=False)
by_station = df.groupby('station')['PM2.5'].agg(rows='size',observed='count')
by_station['missing_n']=by_station.rows-by_station.observed
by_station['missing_pct']=100*by_station.missing_n/by_station.rows
by_station['longest_gap_hours']=episodes.groupby('station').hours.max()
by_station.to_csv(out/'tables/ausencias_por_estacion.csv')
by_month = df.assign(month_start=df.datetime.dt.to_period('M').astype(str)).groupby(['station','month_start'])['PM2.5'].agg(rows='size',observed='count')
by_month['missing_pct']=100*(by_month.rows-by_month.observed)/by_month.rows
by_month.to_csv(out/'tables/ausencias_por_mes.csv')
simultaneous = df.groupby('datetime')['PM2.5_missing'].sum()
simultaneous.value_counts().sort_index().rename_axis('stations_missing').rename('hours').to_csv(out/'tables/ausencias_simultaneas.csv')

# Descriptivos de concentraciones SOLO en desarrollo.
dev = df.loc[df.period.eq('development')]
desc = dev[pollutants+['TEMP','PRES','DEWP','RAIN','WSPM']].describe(percentiles=[.01,.05,.5,.95,.99]).T
desc.to_csv(out/'tables/descriptivos_desarrollo.csv')
dev_month = dev.assign(month_start=dev.datetime.dt.to_period('M').astype(str)).groupby(['station','month_start'])['PM2.5'].mean().unstack('station')
dev_month.to_csv(out/'tables/medias_mensuales_desarrollo.csv')

# Variables disponibles al origen t; la disponibilidad inmediata es un supuesto.
g = df.groupby('station',sort=False)
x = df[['station','datetime','period']+variables].copy()
predictors = ['station']+variables
for c in variables:
    x[c+'_missing']=df[c+'_missing']
    predictors.append(c+'_missing')
for lag in [1,3,6,12,24,48,168]:
    name=f'pm25_lag_{lag}h'
    x[name]=g['PM2.5'].shift(lag)
    predictors.append(name)
for window in [24,168]:
    for stat in ['mean','std','count']:
        name=f'pm25_{stat}_{window}h'
        x[name]=g['PM2.5'].transform(lambda s:getattr(s.rolling(window,min_periods=1),stat)())
        predictors.append(name)
last_valid = df.datetime.where(df['PM2.5'].notna()).groupby(df.station).ffill()
x['pm25_age_hours']=(df.datetime-last_valid).dt.total_seconds()/3600
predictors.append('pm25_age_hours')
for time_name,period in [('hour',24),('dayofweek',7),('month',12)]:
    values = getattr(df.datetime.dt,time_name)
    for fn,label in [(np.sin,'sin'),(np.cos,'cos')]:
        col=f'{time_name}_{label}'
        x[col]=fn(2*np.pi*values/period)
        predictors.append(col)
x['target_time']=df.datetime+pd.Timedelta(hours=24)
x['target_pm25_24h']=g['PM2.5'].shift(-24)
x['target_observed']=x.target_pm25_24h.notna()
limits=x.period.map({'development':split1,'calibration':split2,'test':end})
x['within_split']=x.target_time.lt(limits)
x['history_168h']=g.cumcount().ge(168)
x['eligible']=x.within_split & x.target_observed & x.history_168h
x['exclusion_reason']=np.select([~x.within_split,~x.history_168h,~x.target_observed],
    ['target_outside_split','initial_history_short','target_missing'],default='eligible')
assert x.within_split.eq(False).sum()==12*24*3
assert not set(predictors)&{'period','target_time','target_pm25_24h','target_observed','eligible','within_split','exclusion_reason'}
assert (x.loc[x.eligible,'target_time']<limits[x.eligible]).all()
# Comprobar alineacion a traves de consulta por claves, independiente de shift.
lookup=df.set_index(['station','datetime'])['PM2.5']
sample=x.sample(500,random_state=20261003)
expected=lookup.reindex(pd.MultiIndex.from_arrays([sample.station,sample.target_time])).to_numpy()
np.testing.assert_allclose(sample.target_pm25_24h,expected,equal_nan=True)
for lag in [1,24,168]:
    expected=lookup.reindex(pd.MultiIndex.from_arrays([sample.station,sample.datetime-pd.Timedelta(hours=lag)])).to_numpy()
    np.testing.assert_allclose(sample[f'pm25_lag_{lag}h'],expected,equal_nan=True)
for station in df.station.unique():
    # Una media causal calculada directamente en un origen por estacion.
    origin=x.loc[x.station.eq(station)].iloc[300]
    hist=df.loc[df.station.eq(station)&df.datetime.between(origin.datetime-pd.Timedelta(hours=23),origin.datetime),'PM2.5']
    np.testing.assert_allclose(origin.pm25_mean_24h,hist.mean(),equal_nan=True)
x[['station','datetime','period','target_time','target_observed','within_split','history_168h','eligible','exclusion_reason']].to_csv(out/'data/indice_particiones.csv.gz',index=False,compression={'method':'gzip','mtime':0})
flow=[]
for label,part in x.groupby('period',sort=False):
    selected=part.loc[part.eligible]
    selected[['station','datetime','target_time']+[p for p in predictors if p!='station']+['target_pm25_24h']].to_csv(out/f'data/{label}_24h.csv.gz',index=False,na_rep='NA',compression={'method':'gzip','mtime':0})
    counts=part.exclusion_reason.value_counts()
    flow.append({'period':label,'origin_rows':len(part),'eligible_rows':len(selected),
                 'outside_split':int(counts.get('target_outside_split',0)),
                 'initial_history_short':int(counts.get('initial_history_short',0)),
                 'target_missing':int(counts.get('target_missing',0)),
                 'eligible_current_pm25_missing':int(selected['PM2.5'].isna().sum()),
                 'first_origin':str(selected.datetime.min()),'last_origin':str(selected.datetime.max())})
flow=pd.DataFrame(flow)
assert (flow[['eligible_rows','outside_split','initial_history_short','target_missing']].sum(axis=1)==flow.origin_rows).all()
flow.to_csv(out/'tables/flujo_muestral.csv',index=False)

units={**dict.fromkeys(pollutants,'ug/m3'),'TEMP':'degC','PRES':'hPa','DEWP':'degC','RAIN':'mm','WSPM':'m/s','wd':'categoria'}
dictionary=[]
for name in x.columns:
    role='predictor' if name in predictors else ('response' if name=='target_pm25_24h' else 'metadata_not_predictor')
    meaning=name
    unit=units.get(name,'')
    if name.endswith('_missing'): meaning='1 si falta la medicion al origen; 0 si observada';unit='0/1'
    if name.startswith('pm25_lag_'): meaning='PM2.5 observado exactamente ese numero de horas antes del origen';unit='ug/m3'
    if name.startswith('pm25_mean_'): meaning='Media de observaciones disponibles en ventana retrospectiva incluyendo t';unit='ug/m3'
    if name.startswith('pm25_std_'): meaning='Desviacion estandar muestral ddof=1 en ventana incluyendo t; NA con menos de 2 valores';unit='ug/m3'
    if name.startswith('pm25_count_'): meaning='Numero de mediciones observadas en ventana retrospectiva incluyendo t';unit='conteo'
    if name=='pm25_age_hours': meaning='Horas desde ultima medicion observada hasta t; NA si nunca observada';unit='horas'
    if name=='target_pm25_24h':meaning='Concentracion horaria de PM2.5 en t+24, sin imputacion';unit='ug/m3'
    dictionary.append({'column':name,'role':role,'unit':unit,'description':meaning})
pd.DataFrame(dictionary).to_csv(out/'tables/diccionario_variables.csv',index=False)

plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'savefig.dpi':180})
fig,axes=plt.subplots(1,2,figsize=(11,5),layout='constrained')
ordered=by_station.sort_values('missing_pct')
axes[0].barh(ordered.index,ordered.missing_pct,color='#28618c')
axes[0].set_xlabel('PM2.5 ausente (%)')
axes[0].set_title('(a) Frecuencia de ausencias')
axes[1].barh(ordered.index,ordered.longest_gap_hours,color='#a55438')
axes[1].set_xlabel('Mayor tramo consecutivo (horas)')
axes[1].set_title('(b) Duracion maxima')
for ext in ['png','svg']:fig.savefig(out/f'figures/ausencias_estaciones.{ext}')
plt.close(fig)
heat=by_month.missing_pct.unstack('month_start').reindex(ordered.index)
fig,ax=plt.subplots(figsize=(12,5),layout='constrained')
im=ax.imshow(heat.to_numpy(),aspect='auto',cmap='magma_r',vmin=0)
ax.set_yticks(range(len(heat)),heat.index)
ticks=list(range(0,heat.shape[1],3))
ax.set_xticks(ticks,[heat.columns[i] for i in ticks],rotation=45,ha='right')
ax.axvline(23.5,color='#26bfdd',linestyle='--');ax.axvline(35.5,color='#26bfdd',linestyle='--')
fig.colorbar(im,ax=ax,label='PM2.5 ausente (%)')
for ext in ['png','svg']:fig.savefig(out/f'figures/ausencias_mensuales.{ext}')
plt.close(fig)
fig,ax=plt.subplots(figsize=(11,4),layout='constrained')
for c in dev_month:ax.plot(range(len(dev_month)),dev_month[c],linewidth=1,alpha=.55)
ax.set_xticks(range(0,len(dev_month),3),dev_month.index[::3],rotation=35,ha='right')
ax.set_ylabel('Media mensual observada de PM2.5 (ug/m3)')
ax.set_xlabel('Desarrollo: cada linea representa una estacion')
for ext in ['png','svg']:fig.savefig(out/f'figures/pm25_desarrollo.{ext}')
plt.close(fig)

metadata={'created_utc':datetime.now(timezone.utc).isoformat(),'source_doi':'10.24432/C5RK5G','source_license':'CC BY 4.0',
 'source_sha256':sha,'raw_files_used':files,'python':platform.python_version(),'pandas':pd.__version__,'numpy':np.__version__,'matplotlib':matplotlib.__version__,
 'predictors_allowlist':predictors,'response':'target_pm25_24h','timezone':'Reloj de la fuente conservado sin conversion; zona horaria no verificada',
 'assumption':'Las mediciones de t estan disponibles al emitir el pronostico; latencia real no verificada',
 'test_policy':'Solo auditoria de calidad y conteos de disponibilidad. Sin ajuste ni evaluacion de modelos ni descriptivos de concentraciones en prueba.',
 'checks':['source_hash','420768_rows_12_stations','unique_station_time','hourly_grid','nonnegative_pollutants','missing_episode_reconciliation','864_boundary_origins_excluded','target_alignment_500_origins','lag_alignment_500_origins','causal_mean_12_origins','sample_flow_reconciliation'],
 'checks_passed':True}
(out/'manifest.json').write_text(json.dumps(metadata,indent=2,ensure_ascii=False),encoding='utf-8')
longest=episodes.iloc[0]
flow_text='\n'.join(f"| {r.period} | {r.origin_rows:,} | {r.eligible_rows:,} | {r.outside_split:,} | {r.initial_history_short:,} | {r.target_missing:,} |" for r in flow.itertuples())
missing_text='\n'.join(f'| {r.variable} | {r.missing_n:,} | {r.missing_pct:.2f} % |' for r in missing.itertuples())
report=f'''# Preparación de los datos para el estudio de PM2.5

Se prepararon los 420 768 registros de las 12 estaciones. Los valores originales se conservaron; no se imputaron ausencias, eliminaron extremos ni ajustaron modelos. Fuente: [UCI 501](https://doi.org/10.24432/C5RK5G), Chen (2017), licencia CC BY 4.0.

## Hallazgos de calidad

No hay duplicados por estación y hora ni huecos en la cuadrícula horaria. Sí faltan mediciones dentro de las filas. Hay {len(episodes):,} episodios de PM2.5 ausente. El mayor corresponde a {longest.station}: {longest.start} a {longest.end}, ambos inclusive, con {longest.hours} horas. No se conoce la causa de estas ausencias.

| Variable | Ausencias | Porcentaje de 420 768 filas |
|---|---:|---:|
{missing_text}

![Ausencias por estación](figures/ausencias_estaciones.png)

![Ausencias mensuales](figures/ausencias_mensuales.png)

Las líneas verticales delimitan desarrollo, calibración y prueba. Estos gráficos describen disponibilidad de mediciones en toda la base; no muestran rendimiento predictivo.

## Muestras para pronosticar a 24 horas

Cada fila representa un origen t y su respuesta es la concentración horaria en t+24. Se usa la información hasta t, bajo el supuesto de disponibilidad inmediata. Las fechas se conservan tal como vienen en la fuente, sin conversión de zona horaria.

Desarrollo: 2013-03-01 a 2015-02-28. Calibración: 2015-03-01 a 2016-02-29. Prueba: 2016-03-01 a 2017-02-28. No se aplicó partición aleatoria.

| Periodo | Orígenes iniciales | Elegibles | Objetivo fuera de periodo | Historia inicial menor a 168 h | Objetivo ausente |
|---|---:|---:|---:|---:|---:|
{flow_text}

Las exclusiones son mutuamente excluyentes y se aplican en el orden mostrado. El índice de particiones permite identificar cada fila excluida. Se excluyen 24 orígenes por estación al final de cada periodo para que la respuesta no cruce la frontera. Los primeros siete días se reservan para disponer de una ventana histórica completa; esto no exige que todas sus mediciones estén presentes.

Un objetivo ausente impide evaluar esa fila. Una covariable ausente no elimina automáticamente la fila. Se permite usar el pasado de un periodo anterior al construir rezagos del siguiente, tal como ocurriría al emitir un pronóstico cronológico. No se usan observaciones futuras como predictores.

## Variables preparadas

Se incluyen contaminantes y meteorología en t, indicadores de ausencia, rezagos de PM2.5 de 1, 3, 6, 12, 24, 48 y 168 horas, medias, desviaciones y conteos retrospectivos de 24 y 168 horas, antigüedad de la última observación y codificación cíclica de hora, día de semana y mes. Las ventanas incluyen t; las medias omiten ausencias y se acompañan de su conteo efectivo.

`manifest.json` contiene la lista exacta de columnas autorizadas como predictores. `target_pm25_24h` es únicamente la respuesta. Los indicadores de elegibilidad y observación del objetivo no deben usarse como variables predictoras.

## Exploración del desarrollo

![PM2.5 durante desarrollo](figures/pm25_desarrollo.png)

Las medias mensuales usan solo mediciones observadas; no corrigen la posible selección asociada a las ausencias. Los descriptivos de concentraciones se calcularon exclusivamente sobre desarrollo. Los valores de calibración y prueba se prepararon pero no se usaron para seleccionar modelos ni evaluar su rendimiento.

## Archivos y reproducción

- `raw/uci501.zip`: descarga original íntegra.
- `data/panel_preservado.csv.gz`: columnas originales, fechas, periodos e indicadores de ausencia.
- `data/development_24h.csv.gz`, `calibration_24h.csv.gz`, `test_24h.csv.gz`: muestras elegibles con predictores y respuesta.
- `data/indice_particiones.csv.gz`: trazabilidad de inclusión y exclusión.
- `tables/`: diccionario, conteos, episodios y descriptivos.
- `figures/`: figuras PNG y SVG editables.
- `preparar_datos.py`: reproducción con Python, pandas, numpy y matplotlib; versiones en `manifest.json`.

Ejecutar `python preparar_datos.py` desde cualquier directorio reproduce el paquete a partir del archivo original incluido. Los CSV usan coma como separador, punto decimal, UTF-8 y `NA` para valores ausentes. Pueden leerse con pandas o R. No se requiere Excel.

## Límites y siguiente análisis

La cuadrícula completa no demuestra calidad instrumental. No se han verificado coordenadas, causas de ausencia ni latencias de publicación. La base describe Beijing en 2013–2017 y todavía requiere una fuente externa para evaluar generalización.

La selección de filas con respuesta observada puede sesgar la evaluación si la ausencia depende del nivel de contaminación. Los experimentos de ocultación deben ocultar entradas observadas, conservar la verdad de evaluación y recalcular todas las variables afectadas; no basta con ocultar la columna actual dejando visibles sus derivados. Las duraciones o distribuciones de ocultación deben fijarse con desarrollo, sin usar episodios de prueba para optimizar el procedimiento.

El siguiente paso es cerrar el protocolo y comparar referencias de persistencia, estacionalidad y regresión dentro de desarrollo. Cualquier imputación, escalamiento, selección de variables o ajuste se aprenderá en las ventanas de entrenamiento correspondientes. La prueba se mantiene reservada hasta fijar el procedimiento. Esta preparación no demuestra todavía novedad, mejora predictiva ni nivel Q1.
'''
(out/'INFORME_DATOS.md').write_text(report,encoding='utf-8')
(out/'requirements.txt').write_text(f'pandas=={pd.__version__}\nnumpy=={np.__version__}\nmatplotlib=={matplotlib.__version__}\n',encoding='utf-8')
print(flow.to_string(index=False))
print('Episodios:',len(episodes),'Mayor:',longest.to_dict())
print('Comprobaciones completadas:',len(metadata['checks']))
