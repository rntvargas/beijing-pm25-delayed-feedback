# Ejecutar desde la carpeta descomprimida 02_datos_estudio.
# Solo requiere R base. No imputa datos ni ajusta modelos.
desarrollo <- read.csv(gzfile("data/development_24h.csv.gz"),
                       na.strings = "NA", check.names = FALSE)
diccionario <- read.csv("tables/diccionario_variables.csv",
                       check.names = FALSE)
predictores <- diccionario$column[diccionario$role == "predictor"]
X_desarrollo <- desarrollo[, predictores, drop = FALSE]
y_desarrollo <- desarrollo$target_pm25_24h
stopifnot(nrow(X_desarrollo) == length(y_desarrollo),
          !anyNA(y_desarrollo),
          !"target_pm25_24h" %in% names(X_desarrollo))
print(dim(X_desarrollo))
print(head(desarrollo[, c("station", "datetime", "target_time",
                          "PM2.5", "target_pm25_24h")]))
# Mantener calibracion y prueba separadas hasta cerrar el procedimiento.
