# Preparación de los datos para el estudio de PM2.5

Se prepararon los 420 768 registros de las 12 estaciones. Los valores originales se conservaron; no se imputaron ausencias, eliminaron extremos ni ajustaron modelos. Fuente: [UCI 501](https://doi.org/10.24432/C5RK5G), Chen (2017), licencia CC BY 4.0.

## Hallazgos de calidad

No hay duplicados por estación y hora ni huecos en la cuadrícula horaria. Sí faltan mediciones dentro de las filas. Hay 2,837 episodios de PM2.5 ausente. El mayor corresponde a Aotizhongxin: 2014-12-17 10:00:00 a 2014-12-31 16:00:00, ambos inclusive, con 343 horas. No se conoce la causa de estas ausencias.

| Variable | Ausencias | Porcentaje de 420 768 filas |
|---|---:|---:|
| PM2.5 | 8,739 | 2.08 % |
| PM10 | 6,449 | 1.53 % |
| SO2 | 9,021 | 2.14 % |
| NO2 | 12,116 | 2.88 % |
| CO | 20,701 | 4.92 % |
| O3 | 13,277 | 3.16 % |
| TEMP | 398 | 0.09 % |
| PRES | 393 | 0.09 % |
| DEWP | 403 | 0.10 % |
| RAIN | 390 | 0.09 % |
| wd | 1,822 | 0.43 % |
| WSPM | 318 | 0.08 % |

![Ausencias por estación](figures/ausencias_estaciones.png)

![Ausencias mensuales](figures/ausencias_mensuales.png)

Las líneas verticales delimitan desarrollo, calibración y prueba. Estos gráficos describen disponibilidad de mediciones en toda la base; no muestran rendimiento predictivo.

## Muestras para pronosticar a 24 horas

Cada fila representa un origen t y su respuesta es la concentración horaria en t+24. Se usa la información hasta t, bajo el supuesto de disponibilidad inmediata. Las fechas se conservan tal como vienen en la fuente, sin conversión de zona horaria.

Desarrollo: 2013-03-01 a 2015-02-28. Calibración: 2015-03-01 a 2016-02-29. Prueba: 2016-03-01 a 2017-02-28. No se aplicó partición aleatoria.

| Periodo | Orígenes iniciales | Elegibles | Objetivo fuera de periodo | Historia inicial menor a 168 h | Objetivo ausente |
|---|---:|---:|---:|---:|---:|
| development | 210,240 | 203,710 | 288 | 2,016 | 4,226 |
| calibration | 105,408 | 103,000 | 288 | 0 | 2,120 |
| test | 105,120 | 102,465 | 288 | 0 | 2,367 |

Las exclusiones son mutuamente excluyentes y se aplican en el orden mostrado. El índice de particiones permite identificar cada fila excluida. Se excluyen 24 orígenes por estación al final de cada periodo para que la respuesta no cruce la frontera. Los primeros siete días se reservan para disponer de una ventana histórica completa; esto no exige que todas sus mediciones estén presentes.

Un objetivo ausente impide evaluar esa fila. Una covariable ausente no elimina automáticamente la fila. Se permite usar el pasado de un periodo anterior al construir rezagos del siguiente, tal como ocurriría al emitir un pronóstico cronológico. No se usan observaciones futuras como predictores.

## Variables preparadas

Se incluyen contaminantes y meteorología en t, indicadores de ausencia, rezagos de PM2.5 de 1, 3, 6, 12, 24, 48 y 168 horas, medias, desviaciones y conteos retrospectivos de 24 y 168 horas, antigüedad de la última observación y codificación cíclica de hora, día de semana y mes. Las ventanas incluyen t; las medias omiten ausencias y se acompañan de su conteo efectivo.

`manifest.json` contiene la lista exacta de columnas autorizadas como predictores. `target_pm25_24h` es únicamente la respuesta. Los indicadores de elegibilidad y observación del objetivo no deben usarse como variables predictoras.

## Exploración del desarrollo

![PM2.5 durante desarrollo](figures/pm25_desarrollo.png)

Las medias mensuales usan solo mediciones observadas; no corrigen la posible selección asociada a las ausencias. Los descriptivos de concentraciones se calcularon exclusivamente sobre desarrollo. Los valores de calibración y prueba se prepararon pero no se usaron para seleccionar modelos ni evaluar su rendimiento.

## Archivos y reproducción

- `raw/uci501.zip`: descarga original íntegra.
- `data/panel_preservado.csv.gz`: columnas originales, fechas, periodos e indicadores de ausencia.
- `data/development_24h.csv.gz`, `calibration_24h.csv.gz`, `test_24h.csv.gz`: muestras elegibles con predictores y respuesta.
- `data/indice_particiones.csv.gz`: trazabilidad de inclusión y exclusión.
- `tables/`: diccionario, conteos, episodios y descriptivos.
- `figures/`: figuras PNG y SVG editables.
- `preparar_datos.py`: reproducción con Python, pandas, numpy y matplotlib; versiones en `manifest.json`.

Ejecutar `python preparar_datos.py` desde cualquier directorio reproduce el paquete a partir del archivo original incluido. Los CSV usan coma como separador, punto decimal, UTF-8 y `NA` para valores ausentes. Pueden leerse con pandas o R. No se requiere Excel.

## Límites y siguiente análisis

La cuadrícula completa no demuestra calidad instrumental. No se han verificado coordenadas, causas de ausencia ni latencias de publicación. La base describe Beijing en 2013–2017 y todavía requiere una fuente externa para evaluar generalización.

La selección de filas con respuesta observada puede sesgar la evaluación si la ausencia depende del nivel de contaminación. Los experimentos de ocultación deben ocultar entradas observadas, conservar la verdad de evaluación y recalcular todas las variables afectadas; no basta con ocultar la columna actual dejando visibles sus derivados. Las duraciones o distribuciones de ocultación deben fijarse con desarrollo, sin usar episodios de prueba para optimizar el procedimiento.

El siguiente paso es cerrar el protocolo y comparar referencias de persistencia, estacionalidad y regresión dentro de desarrollo. Cualquier imputación, escalamiento, selección de variables o ajuste se aprenderá en las ventanas de entrenamiento correspondientes. La prueba se mantiene reservada hasta fijar el procedimiento. Esta preparación no demuestra todavía novedad, mejora predictiva ni nivel Q1.
