# Verificacion independiente de metricas a partir de predicciones guardadas.
# Uso: Rscript verificar_resultados.R <directorio_del_experimento>
args <- commandArgs(trailingOnly = TRUE)
base <- if (length(args)) args[1] else "."
expected <- read.csv(file.path(base, "tables", "interval_metrics.csv"), check.names = FALSE)
checks <- list()
for (delay in c(0, 6, 24, 72, 168)) {
  d <- read.csv(gzfile(file.path(base, "predictions", paste0("delay_", delay, "h.csv.gz"))), check.names = FALSE)
  y <- d$target_pm25_24h
  stopifnot(!anyNA(y), nrow(d) == 102465)
  for (nominal in c(0.9, 0.95)) {
    for (method in unique(expected$method)) {
      low <- d[[paste0(method, "_lower_", sprintf("%.2f", nominal))]]
      up <- d[[paste0(method, "_upper_", sprintf("%.2f", nominal))]]
      stopifnot(all(is.finite(low)), all(is.finite(up)), all(low <= up), all(low >= 0))
      score <- up - low + 2/(1-nominal) * (pmax(low-y, 0) + pmax(y-up, 0))
      observed <- c(coverage = mean(y >= low & y <= up), width = mean(up-low), interval_score = mean(score))
      row <- expected[expected$delay_h == delay & abs(expected$nominal-nominal)<1e-9 & expected$method == method, ]
      stopifnot(nrow(row)==1, max(abs(observed-as.numeric(row[1, names(observed)]))) < 1e-8)
      checks[[length(checks)+1]] <- data.frame(delay_h=delay, nominal=nominal, method=method, verified=TRUE)
    }
  }
}
p <- read.csv(file.path(base, "tables", "primary_daily_paired_differences.csv"))
b <- read.csv(file.path(base, "tables", "primary_bootstrap.csv"))
estimate <- sum(p$difference)/sum(p$n)
stopifnot(max(abs(b$estimate-estimate))<1e-8)
write.csv(do.call(rbind, checks), file.path(base,"tables","verificacion_R.csv"),row.names=FALSE)
writeLines(c(paste("R:",R.version.string),paste("Interval metrics verified:",length(checks)),
             paste("Primary estimate:",format(estimate,digits=15)),"Tolerance: 1e-8"),
           file.path(base,"VERIFICACION_R.txt"))
cat("Verificacion independiente completada:",length(checks),"combinaciones.\n")
