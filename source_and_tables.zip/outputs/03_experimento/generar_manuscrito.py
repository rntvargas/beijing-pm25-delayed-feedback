from pathlib import Path
import os, tempfile, json, shutil
os.environ.setdefault('MPLCONFIGDIR',str(Path(tempfile.gettempdir())/'codex-paper-mpl'))
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

BASE=Path(__file__).resolve().parents[2]
E=BASE/'outputs/03_experimento';O=BASE/'outputs/04_manuscrito_springer'
metrics=pd.read_csv(E/'tables/interval_metrics.csv')
points=pd.read_csv(E/'tables/point_metrics.csv')
cv=pd.read_csv(E/'tables/cv_summary.csv')
boot=pd.read_csv(E/'tables/primary_bootstrap.csv')
sub=pd.read_csv(E/'tables/subgroup_metrics.csv')
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.spines.top':False,'axes.spines.right':False,'savefig.dpi':300})
labels={'static_unmatched':'Static, no-delay calibration','static_matched':'Static, delay-matched calibration','rolling_valid':'Rolling, arrival-aware calibration'}
colors=['#24628b','#ab602b','#258066']
fig,axes=plt.subplots(1,3,figsize=(10.5,3.25),layout='constrained')
for method,color in zip(labels,colors):
    d=metrics[(metrics.nominal==.9)&(metrics.method==method)]
    for ax,key in zip(axes,['coverage','width','interval_score']):
        ax.plot(range(5),d[key]*(100 if key=='coverage' else 1),marker='o',color=color,label=labels[method])
        ax.set_xticks(range(5),d.delay_h);ax.set_xlabel('PM2.5 delivery delay (h)')
axes[0].axhline(90,color='black',ls='--',lw=.8);axes[0].set_ylim(85,91)
for ax,title,ylabel in zip(axes,['(a) Coverage','(b) Width','(c) Interval score'],['Empirical coverage (%)',r'Mean width ($\mu$g/m$^3$)',r'Mean score ($\mu$g/m$^3$)']):ax.set_title(title,loc='left');ax.set_ylabel(ylabel)
handles,labs=axes[0].get_legend_handles_labels();fig.legend(handles,labs,loc='outside lower center',ncol=1,frameon=False)
fig.savefig(O/'Fig1.png');plt.close(fig)

fig,axes=plt.subplots(1,2,figsize=(8.2,3.3),layout='constrained')
for model,color in zip(['persistence','station_hour_mean','ridge','hgb'],['#777777','#b78c38','#9960aa','#24628b']):
    d=points[points.model==model]
    for ax,key in zip(axes,['mae','rmse']):ax.plot(range(5),d[key],marker='o',color=color,label={'persistence':'Persistence','station_hour_mean':'Station-hour mean','ridge':'Ridge','hgb':'Boosting'}[model]);ax.set_xticks(range(5),d.delay_h);ax.set_xlabel('PM2.5 delivery delay (h)')
axes[0].set_ylabel(r'MAE ($\mu$g/m$^3$)');axes[1].set_ylabel(r'RMSE ($\mu$g/m$^3$)')
axes[0].set_title('(a) Absolute error',loc='left');axes[1].set_title('(b) Squared error',loc='left')
handles,labs=axes[0].get_legend_handles_labels();fig.legend(handles,labs,loc='outside lower center',ncol=4,frameon=False)
fig.savefig(O/'Fig2.png');plt.close(fig)

d=sub[(sub.delay_h==72)&(sub.nominal==.9)&(sub.method=='rolling_valid')]
fig,axes=plt.subplots(1,2,figsize=(8.4,4),layout='constrained')
st=d[d.group=='station'].sort_values('coverage');q=d[d.group=='quarter']
axes[0].barh(st.value,st.coverage*100,color='#24628b');axes[0].set_xlim(75,100);axes[0].set_xlabel('Coverage (%)');axes[0].axvline(90,color='black',ls='--',lw=.9);axes[0].set_title('(a) By station',loc='left')
axes[1].bar(q.value,q.coverage*100,color='#258066');axes[1].set_ylim(75,100);axes[1].axhline(90,color='black',ls='--',lw=.9);axes[1].tick_params(axis='x',rotation=45);axes[1].set_title('(b) By calendar quarter',loc='left');axes[1].set_ylabel('Coverage (%)')
fig.savefig(O/'Fig3.png');plt.close(fig)

fig,ax=plt.subplots(figsize=(7.5,2.8),layout='constrained')
ax.errorbar(boot.estimate,range(3),xerr=np.array([boot.estimate-boot.lower95,boot.upper95-boot.estimate]),fmt='o',capsize=5,color='#24628b')
ax.axvline(0,color='black',ls='--',lw=.9);ax.set_yticks(range(3),[f'{n}-day blocks' for n in boot.block_days]);ax.invert_yaxis();ax.set_xlabel(r'Rolling minus static interval score ($\mu$g/m$^3$)')
fig.savefig(O/'Fig4.png');plt.close(fig)

names={'hgb_15_100':'Boosting: 15 leaves, 100 iterations','hgb_31_100':'Boosting: 31 leaves, 100 iterations','hgb_31_200':'Boosting: 31 leaves, 200 iterations','ridge_1':'Ridge: alpha 1','ridge_10':'Ridge: alpha 10','ridge_100':'Ridge: alpha 100','station_hour_mean':'Station-hour mean','persistence':'Persistence'}
cvrows='\n'.join(f'{names[r.model]} & {r.mae:.2f} & {r.rmse:.2f} \\\\' for r in cv.itertuples())
q=metrics[(metrics.delay_h==72)&metrics.method.isin(labels)]
table='\n'.join(f"{int(r.nominal*100)} & {{'static_unmatched':'Static unmatched','static_matched':'Static matched','rolling_valid':'Rolling valid'}}" for r in [])
short={'static_unmatched':'Static unmatched','static_matched':'Static matched','rolling_valid':'Rolling valid'}
introws='\n'.join(f'{int(r.nominal*100)} & {short[r.method]} & {r.coverage*100:.2f} & {r.width:.2f} & {r.interval_score:.2f} \\\\' for r in q.itertuples())
btrows='\n'.join(f'{r.block_days} & {r.estimate:.2f} & [{r.lower95:.2f}, {r.upper95:.2f}] \\\\' for r in boot.itertuples())

tex=r'''\documentclass[pdflatex,sn-mathphys-ay]{sn-jnl}
\usepackage{graphicx}
\usepackage{amsmath,amssymb,booktabs}
\usepackage{xurl}
\let\burl\url
\raggedbottom
\begin{document}
\title[Delayed observations in PM2.5 forecasting]{Delayed measurements and delayed feedback in PM2.5 interval forecasting: a reproducible Beijing benchmark}
\abstract{Observation latency affects both the inputs of a forecasting model and the errors available for recalibrating its prediction intervals. This retrospective study examines these two restrictions jointly using 420,768 hourly records from 12 Beijing monitoring stations. A chronological design separates model development, interval calibration and a final test set of 102,465 observed targets. Four point-prediction families are compared, and a fixed gradient-boosting predictor is evaluated under simulated PM2.5 delivery delays of 0, 6, 24, 72 and 168 hours. Static calibration without delay, delay-matched static calibration and an arrival-aware rolling calibration are assessed at nominal levels of 90\% and 95\%. At a 72-hour delay, the rolling method reduces mean 90\% interval score from 377.14 to 328.01 micrograms per cubic metre, while increasing mean width from 169.20 to 184.09. Its empirical coverage remains below nominal at 88.32\%. The paired score difference is -49.13, with a seven-day block-bootstrap interval of [-107.13, -3.02]; intervals using 14- and 28-day blocks include zero. Coverage also varies substantially across stations and calendar quarters. These findings show that better average interval scores need not imply nominal coverage or robust evidence of superiority. The benchmark provides an auditable evaluation of existing calibration strategies under delayed information, rather than a new conformal method or a distribution-free guarantee for dependent environmental data.}
\keywords{PM2.5 forecasting, observation latency, uncertainty quantification, temporal validation, conformal calibration, environmental informatics}
\maketitle
\begin{center}\small Working research manuscript. Authorship and affiliation metadata await confirmation. Not submitted to a journal.\end{center}

\section{Introduction}
Air-quality forecasts are made with the measurements available at their issue time. Retrospective datasets, in contrast, often provide a completed archive without an explicit record of publication latency. A forecast evaluation can therefore inadvertently grant access to measurements, or to forecast errors, before they would have become available. This distinction matters when prediction intervals are recalibrated online: the observed response needed to score an earlier forecast may itself be delayed.

Conformal inference offers a general route from predictive models to uncertainty sets. Adaptive conformal inference addresses distribution shift \citep{gibbs2021}, and subsequent work studies its behaviour and aggregation for dependent series \citep{zaffran2022}. Sequential predictive conformal inference explicitly exploits dependence in conformity scores \citep{xu2023}. Missing covariates introduce another difficulty: average coverage can conceal poor coverage for particular missingness patterns \citep{zaffran2023}. These established contributions motivate an empirical evaluation that keeps information availability explicit.

The present study uses the Beijing multi-site air-quality archive \citep{chen2017,zhang2017} to ask how point and interval forecasts change when the PM2.5 channel arrives late. The analysis does not propose a new conformal algorithm. Its contribution is a reproducible, temporally separated benchmark in which the same simulated delay governs both feature construction and eligibility of residuals for recalibration. An intentionally infeasible feedback rule, which ignores the latter restriction, is reported separately as a diagnostic.

Three questions guide the experiment. How much do simple point predictors deteriorate under increasing delay? Does matching the calibration information state or updating calibration over time improve interval performance? Are the resulting conclusions stable across locations, calendar periods and dependence-sensitive uncertainty calculations? Interval score is used alongside coverage and width to avoid rewarding intervals solely for being wide \citep{gneiting2007}.

\section{Data and chronological design}
\subsection{Source and audit}
The UCI dataset contains hourly air-pollutant and meteorological records at 12 Beijing sites from 1 March 2013 through 28 February 2017. It is distributed under CC BY 4.0 \citep{chen2017}. The analysis uses the twelve original station files inside the archived PRSA2017 data package. Auxiliary files named \texttt{data.csv} and \texttt{test.csv} in the outer download are not included. A source checksum and file manifest are retained in the reproducibility materials.

There are 420,768 station-hour records and 18 original columns. The audit found no duplicate station-time keys and no discontinuities in the hourly row grid. PM2.5 is missing in 8,739 records (2.08\%). These absences form 2,837 contiguous station-specific episodes; the longest lasts 343 hours at Aotizhongxin, from 17 December 2014 at 10:00 through 31 December 2014 at 16:00. Across the archive, 81 hourly timestamps have no PM2.5 measurement at any of the twelve sites. These are descriptions of recorded availability, not confirmed sensor failures.

Raw concentrations are preserved without outlier deletion or response imputation. No negative values occur in the six pollutant channels, but this check does not establish instrumental accuracy. Predictor absences remain explicit. Time stamps retain the source clock; no time-zone conversion or real publication-time reconstruction is claimed. Audits of missingness used the complete archive before the experiment, whereas model selection and concentration summaries were restricted to development data.

\subsection{Forecast target and sample flow}
For site $s$ and issue time $t$, the response is the hourly concentration $Y_{s,t+24}$, not a daily average. Model development covers March 2013--February 2015, interval calibration covers March 2015--February 2016, and the final test covers March 2016--February 2017. The last 24 issue times per site in each period are excluded so that their response does not cross the period boundary. The first 168 hours of the archive are reserved for constructing the longest historical window. A missing response prevents scoring that origin; a missing input does not automatically remove it.

\begin{table}[htbp]
\caption{Sample flow. Exclusions are mutually exclusive and applied from left to right. Counts refer to station-specific forecast origins.}\label{tab:flow}
\centering\small
\begin{tabular}{@{}lrrrrr@{}}\toprule
Period & Initial & Boundary & History & Response NA & Eligible\\\midrule
Development & 210,240 & 288 & 2,016 & 4,226 & 203,710\\
Calibration & 105,408 & 288 & 0 & 2,120 & 103,000\\
Test & 105,120 & 288 & 0 & 2,367 & 102,465\\\botrule
\end{tabular}
\end{table}

The test includes origins from 1 March 2016 through 27 February 2017; their responses extend through 28 February. Observations from an earlier period can supply historical inputs for a later period, as they would in chronological deployment. No random train-test split is used. The same 102,465 test origins are evaluated under every delay, enabling paired comparisons. This conditions evaluation on originally observed responses and does not establish performance when the unobserved target values are systematically different.

\section{Methods}
\subsection{Information sets and simulated delay}
Let $d\in\{0,6,24,72,168\}$ denote a constant PM2.5 delivery delay in hours. At issue time $t$, the PM2.5 history is restricted to times $u\leq t-d$. Other pollutant and meteorological channels are assumed to be available at $t$, retaining their natural missingness. Thus the experiment represents a delayed pollutant channel, not loss of an entire station or a measured latency distribution. The zero-delay condition still contains all naturally missing values.

The baseline feature set contains station identity, current pollutants and meteorology, missingness indicators, PM2.5 lags of 1, 3, 6, 12, 24, 48 and 168 hours, retrospective means, standard deviations and observed counts over 24 and 168 hours, age of the most recent available PM2.5 value, and sinusoidal calendar encodings. Station and wind-direction categories are one-hot encoded using development categories. For $d>0$, current PM2.5 is hidden, lags shorter than $d$ are hidden, and all dependent summaries are rebuilt. Specifically, a $w$-hour summary uses only
\begin{equation}
\{Y_{s,u}:t-w+1\leq u\leq t-d,\;Y_{s,u}\text{ observed}\}.
\end{equation}
If this set is empty, its mean and standard deviation are missing and its count is zero. Age is computed from the latest observed time no later than $t-d$. Univariate summaries omit missing values and carry their effective count. They never interpolate from future measurements.

\subsection{Point predictors and development selection}
Four model families are considered: last-observation persistence; a training mean by station and response hour; Ridge regression; and histogram gradient boosting with absolute-error loss. Persistence falls back to a station-specific median of training responses if no historical value is available. Ridge uses training-median imputation and standardization. Boosting handles numerical missing values directly. All point predictions are truncated below at zero.

Three expanding-origin validation windows cover March--June 2014, July--October 2014 and November 2014--February 2015. Each training set contains only responses dated before the corresponding window. The validation windows also exclude targets beyond their right boundary. Ridge penalties are 1, 10 and 100. Boosting configurations comprise 15 leaves and 100 iterations, 31 leaves and 100 iterations, and 31 leaves and 200 iterations, with learning rate 0.05, minimum leaf size 40 and $L_2$ regularization 1. Random early stopping is disabled. Configuration selection minimizes the unweighted mean of the three validation MAEs, separately within each family.

The selected models are refitted on the full development period, with no retraining during calibration or test. A fixed boosting model is used for the interval comparisons, as specified before evaluation. All four families remain in the point-forecast comparison even when rankings change under delay. The protocol is a locally recorded analysis plan, not a public preregistration.

\subsection{Residual calibration with arrival restrictions}
For a fixed predictor $\widehat f_d$ evaluated with delayed features, let
\begin{equation}
R_{s,t,d}=|Y_{s,t+24}-\widehat f_d(X_{s,t}^{(d)})|.
\end{equation}
The notation does not imply separate predictor training by delay: the same fitted model receives the differently observed features. Given $n$ available residuals and nominal level $1-\alpha$, define $q_\alpha$ as the residual of rank $\lceil(n+1)(1-\alpha)\rceil$. The prediction interval is
\begin{equation}
C_{s,t,d}=\left[\max\{0,\widehat Y_{s,t+24,d}-q_\alpha\},\;\widehat Y_{s,t+24,d}+q_\alpha\right].
\end{equation}
Nominal levels are 90\% and 95\%. Residuals are pooled across stations. This finite-sample quantile convention follows conformal calibration, but dependence and distribution changes preclude asserting an automatic distribution-free guarantee here.

Static unmatched calibration uses residuals computed without an imposed delay, applying the same quantile to every delayed scenario. Static matched calibration recomputes the residuals under the scenario's feature delay. Both use calibration responses before 23 February 2016 at 00:00, a common cutoff seven days before the first test origin that makes them available under all delays.

Rolling valid calibration is updated once per day. At the start of day $a$, it uses residuals with response measurement times $v$ satisfying
\begin{equation}
a-d-30\text{ days}<v\leq a-d.
\end{equation}
The associated forecast origins are at most $a-d-24$ hours. Eligible residuals can come from the calibration period or earlier test forecasts once their responses arrive. Quantiles remain fixed within a day, while point forecasts change hourly. As an implementation diagnostic, a fourth method sets the feedback delay to zero while retaining the delayed input features. For $d>0$ this rule is operationally infeasible and is excluded from claims about deployable methods.

\subsection{Evaluation and uncertainty}
Point metrics are MAE and RMSE. Interval evaluation reports empirical coverage, mean width, and the interval score
\begin{align}
\mathrm{IS}_{\alpha}(l,u;y)={}&(u-l)+\frac{2}{\alpha}(l-y)\mathbf{1}(y<l)\nonumber\\
&+\frac{2}{\alpha}(y-u)\mathbf{1}(y>u),
\end{align}
which combines interval width and penalties for observations outside its limits \citep{gneiting2007}. Smaller scores are better. Scores and widths have the same concentration units as the response. Marginal coverage and subgroup coverage are both reported; neither is inferred from interval score alone.

The prespecified primary comparison is rolling valid minus static unmatched interval score at 90\% nominal coverage and $d=72$ hours. Daily sums of paired score differences and daily observation counts are resampled together, retaining all stations within each sampled day. A circular block bootstrap uses 1,000 replications, seven-day blocks, and percentile limits of 2.5\% and 97.5\%. Fourteen- and 28-day blocks assess sensitivity. These intervals condition on the fitted models and this network; they omit model-refitting uncertainty. Nonstationarity and the artificial year-end join of a circular bootstrap remain limitations. No hourly independence-based significance test is used.

\subsection{Reproducibility and verification}
The accompanying materials include source and protocol hashes, exact partitions, feature specifications, model selection results, fitted estimators, predictions for every delay and tabulated outcomes. Feature checks compare sampled lag values and retrospective means against direct time-key lookups. A separate R implementation recomputes coverage, width and interval score from saved predictions for all 40 method-level combinations, agreeing with Python within $10^{-8}$. The primary paired mean is independently reconciled. Python 3.12.14 and R 4.5.2 were used; package versions are recorded with the executable scripts. This verifies arithmetic consistency, not scientific validity of all assumptions.

\section{Results}
\subsection{Temporal selection and point forecasts}
The smallest boosting configuration achieves the lowest mean validation MAE (53.00), compared with 60.04 for persistence. Increasing tree complexity does not improve the aggregate selection criterion (Table~\ref{tab:cv}). Ridge with penalty 100 has the lowest validation RMSE, 70.79, although its MAE is higher than boosting. The selection therefore already displays a trade-off between error criteria.

\begin{table}[htbp]\caption{Mean development-validation errors across the three temporal windows, in $\mu$g/m$^3$. Configuration selection uses MAE within each family.}\label{tab:cv}
\centering\small\begin{tabular}{@{}lrr@{}}\toprule Model & MAE & RMSE\\\midrule
@@CVROWS@@
\botrule\end{tabular}\end{table}

On the final test without additional delay, boosting obtains MAE 51.27, versus 58.12 for persistence and 53.06 for Ridge. Ridge again has smaller RMSE, 73.91 versus 79.53 for boosting. With a 72-hour delay, boosting MAE increases to 55.66 and Ridge MAE is 53.44. Persistence deteriorates to 78.52. These comparisons concern a forecast 24 hours ahead even when its PM2.5 history is several days old. The other pollutant channels remain current by design, and may retain information correlated with the missing channel.

\begin{figure}[htbp]\centering\includegraphics[width=\textwidth]{Fig2.png}
\caption{Point-forecast errors under the five PM2.5 delivery delays. Models are trained once on development data and evaluated on identical test origins. The ordering of models depends on the error criterion and delay.}\label{fig:point}\end{figure}

\subsection{Interval performance under delay}
At $d=72$ hours and 90\% nominal coverage, the static unmatched interval has coverage 88.15\%, width 169.20 and score 377.14. Static matching changes these to 88.41\%, 170.64 and 375.39. Rolling valid calibration attains coverage 88.32\%, width 184.09 and score 328.01 (Table~\ref{tab:intervals}). Its average score is 13.03\% lower than static unmatched calibration, but its intervals are wider and its coverage remains below 90\%. Thus neither matching nor rolling updating establishes nominal coverage.

\begin{table}[htbp]\caption{Test interval metrics at a 72-hour delay. Coverage is expressed as a percentage; width and score are in $\mu$g/m$^3$. Each row uses 102,465 targets.}\label{tab:intervals}
\centering\small\begin{tabular}{@{}rlrrr@{}}\toprule Nominal & Method & Coverage & Width & Score\\\midrule
@@INTROWS@@
\botrule\end{tabular}\end{table}

At 95\% nominal coverage, static matching achieves 94.58\% coverage and score 438.42, whereas rolling valid calibration attains 93.14\% and score 391.54. Better average score therefore coexists with a larger coverage deficit. Across the five delays, rolling calibration improves the average score relative to the static unmatched reference, but the experiment does not demonstrate a universal ordering of calibration quality (Fig.~\ref{fig:intervals}).

\begin{figure}[htbp]\centering\includegraphics[width=\textwidth]{Fig1.png}
\caption{Coverage, width and interval score at the 90\% nominal level. Delay values are discrete experimental scenarios shown at equally spaced positions. The dashed line marks nominal coverage; all three approaches fall below it in aggregate.}\label{fig:intervals}\end{figure}

\subsection{Feedback timing, heterogeneity and inferential sensitivity}
The infeasible rolling diagnostic gives score 324.82 rather than 328.01 at 90\% and a 72-hour delay. At 95\% with a 168-hour delay it gives 385.01 rather than 399.95, making performance appear about 3.74\% better if response arrival is ignored. These are descriptive differences from one test year. They do not justify assuming that premature feedback improves every metric or every subgroup.

For rolling valid intervals at 90\% and $d=72$, station-level coverage ranges from 85.60\% at Dongsi to 91.93\% at Huairou. Calendar-quarter coverage ranges from 81.91\% in 2016Q4 to 95.29\% in 2017Q1. The first and last calendar quarters are partial: 2016Q1 contains March only, and 2017Q1 contains January and February test origins. Subgroup results are descriptive and were not used to retune the evaluated models.

\begin{figure}[htbp]\centering\includegraphics[width=\textwidth]{Fig3.png}
\caption{Coverage heterogeneity for arrival-aware rolling intervals at a 72-hour delay and a 90\% nominal level. The dashed lines indicate nominal coverage. Partial first and last quarters and unequal numbers of observed targets limit direct seasonal comparisons.}\label{fig:groups}\end{figure}

The primary paired score difference is -49.13. Its seven-day block-bootstrap interval excludes zero narrowly, but the intervals using 14- and 28-day blocks include zero (Table~\ref{tab:bootstrap}; Fig.~\ref{fig:bootstrap}). Consequently the result is suggestive of a lower average score in this sample, not robust evidence of superiority across reasonable block lengths. Treating 102,465 dependent test records as independent would not reflect this sensitivity.

\begin{table}[htbp]\caption{Sensitivity of the primary paired score comparison to bootstrap block length. Negative values favour rolling valid calibration over static unmatched calibration.}\label{tab:bootstrap}
\centering\begin{tabular}{@{}rrl@{}}\toprule Block (days) & Difference & 95\% percentile interval\\\midrule
@@BTROWS@@
\botrule\end{tabular}\end{table}

\begin{figure}[htbp]\centering\includegraphics[width=.95\textwidth]{Fig4.png}
\caption{Paired interval-score difference and block-bootstrap limits at 90\% nominal coverage and a 72-hour delay. All estimates use the same observed targets and fixed fitted predictor.}\label{fig:bootstrap}\end{figure}

\section{Discussion}
Three observations stand out. First, temporal validation does not support a simple claim that more complex boosting configurations are preferable. Ridge and boosting trade places depending on the metric and delay. This argues for retaining transparent baselines and several error criteria when reporting an environmental forecasting model.

Second, the central difficulty is not only the loss of a recent predictor. The available residual sample also changes when the target channel arrives late. The diagnostic results quantify an apparent improvement that can arise when this constraint is ignored, especially at long delays and higher nominal coverage. A reproducible benchmark should therefore specify an arrival time for every measurement entering its update rule, not merely avoid future covariates in the original feature matrix.

Third, calibration choices involve trade-offs. Rolling residuals produce better average scores here, but their 95\% coverage is lower than the delay-matched static method. Static matching partly compensates for predictor degradation without guaranteeing nominal coverage. Strong variation among quarters and stations further cautions against treating the network-wide average as a property shared by every location or future period. These findings are consistent with the broader distinction between marginal and more local notions of coverage in missing-data inference \citep{zaffran2023}.

The findings should not be read as a comparison with modern adaptive conformal algorithms. ACI, SPCI, ensemble-based interval methods and missing-data augmentation are not executed in this version. They address related problems using update or learning mechanisms beyond the simple residual windows used here \citep{gibbs2021,zaffran2022,xu2023,zaffran2023}. Conformalized quantile regression is another relevant comparator because the interval widths in this study arise primarily from pooled residual distributions and lower-bound truncation, rather than a fitted conditional scale \citep{romano2019}. Applying such methods fairly would still require the same delayed-feedback restrictions.

Several design choices constrain interpretation. Simulated constant delays do not reproduce intermittent network failures, outcome-dependent missingness, or co-occurring loss of other channels. Reusing current correlated pollutants can soften the effect of delayed PM2.5. Natural missing responses are not recovered, so scoring is conditional on observation. There is only one city and one final test year. Training only under the original availability pattern also measures sensitivity to a changed information state; it does not measure the best attainable model if training were augmented for every delay.

The bootstrap intervals condition on the fitted predictor and assume that resampling time blocks gives a useful approximation despite seasonal changes. They omit uncertainty from model selection and refitting, and cannot turn twelve correlated stations into independent regional replications. Sensitivity to block length is therefore a substantive result rather than a technical detail. The evidence is insufficient to claim general improvement, operational readiness, or a new distribution-free guarantee.

\section{Conclusion}
A latency-aware evaluation of PM2.5 forecasts must track both measurement availability and the arrival of responses used for recalibration. In this Beijing benchmark, rolling calibration lowers average interval score while failing to achieve nominal coverage uniformly. Apparent superiority is sensitive to the bootstrap block length, and subgroup coverage varies materially. The practical outcome is an auditable benchmark and a caution against equating improved mean scores with reliable probabilistic forecasts. External replication and stronger algorithmic comparisons are required before broad methodological claims or deployment recommendations.

\backmatter
\section*{Supplementary information}
The local research package contains the data-preparation script and original archive, chronological split indices, the locally recorded protocol, development scores, all test predictions, subgroup and bootstrap tables, and the independent R verification script. A public archival repository and persistent identifier for the generated materials have not yet been created.

\bibliography{references}

\section*{Statements and Declarations}
\subsection*{Data and code availability}
The source dataset is publicly available from UCI at \url{https://doi.org/10.24432/C5RK5G}. Derived data, predictions and executable code accompany this working manuscript locally. Source checksums, protocol hashes and software versions are included. No claim of public code deposition is made.
\subsection*{Use of artificial intelligence}
OpenAI Codex assisted with literature searches, study design, programming, execution, result checking and drafting. Numerical results were calculated from the stated data. Authors must review the complete analysis, verify references and assume responsibility for the final submission; this review has not yet been documented. The AI system is not an author.
\subsection*{Authorship, funding and competing interests}
Author names, affiliations, contributions, funding and competing-interest declarations have not yet been supplied. They must be completed and confirmed by the research team before submission; no absence of funding or conflicts is presumed.
\subsection*{Ethics}
The analysis uses publicly distributed environmental measurements and contains no participant-level health records. Any institution-specific determination or statement required by the selected journal remains for the authors to confirm.
\end{document}
'''
tex=tex.replace('@@CVROWS@@',cvrows).replace('@@INTROWS@@',introws).replace('@@BTROWS@@',btrows)
# Manuscript revised independently; preserve the curated manuscript.tex.
summary='''# Resultados y estado del manuscrito

Se ejecutó el protocolo local de Beijing y se redactó un manuscrito en inglés con la clase oficial Springer Nature. Es una versión de investigación para revisión, no un artículo aceptado ni un manuscrito declarado listo para Q1.

## Resultados calculados

- 102 465 objetivos observados de prueba, idénticos en los cinco escenarios.
- Sin retraso añadido: MAE del boosting 51,27 µg/m³; persistencia 58,12; Ridge 53,06. Ridge tiene mejor RMSE que boosting.
- Retraso de 72 h, nivel nominal del 90 %: puntuación de intervalos 377,14 con calibración estática sin retraso y 328,01 con calibración móvil válida. Diferencia -49,13; mejora media descriptiva del 13,03 %.
- La cobertura móvil es 88,32 %, inferior al 90 %. Su amplitud media es mayor: 184,09 frente a 169,20 µg/m³.
- El intervalo bootstrap de la diferencia es [-107,13; -3,02] con bloques de 7 días. Con bloques de 14 o 28 días incluye cero: la conclusión de superioridad no es robusta a esa elección.
- R verificó independientemente las métricas de las 40 combinaciones con tolerancia de 1e-8.

## Interpretación

El resultado no es que el método nuevo gane: no se ha inventado un nuevo método y la mejora no es concluyente bajo todas las comprobaciones. La aportación del experimento es evaluar de forma reproducible cómo la llegada tardía de PM2.5 limita tanto los predictores como los errores disponibles para actualizar intervalos. Se conservó un diagnóstico inviable que ignora el retraso de la respuesta para mostrar su efecto sobre las métricas, claramente separado de los métodos operativos.

La prueba ya fue evaluada después de fijar el protocolo y seleccionar las configuraciones en desarrollo. No debe volver a usarse para optimizar la misma comparación ni presentarse como una nueva prueba independiente en versiones posteriores.

## Antes de un envío competitivo

Faltan validación externa, comparadores como ACI/SPCI/CP-MDA o regresión por cuantiles conformalizada, revisión completa de los trabajos más cercanos y confirmación de autores, afiliaciones, contribuciones y declaraciones. Se localizó el portal oficial de datos horarios de Madrid como candidato para la réplica, pero sus datos no se incorporaron al experimento. Sus marcas horarias y cambios de horario requieren tratamiento específico.

La categoría y el año de Q1 deben verificarse en la base exigida por la universidad. La plantilla Springer no acredita calidad Q1 ni garantiza aceptación.

## Reproducción

Con las carpetas 02_datos_estudio y 03_experimento juntas, instalar las dependencias registradas y ejecutar primero `python experimento.py --stage development`, luego `python experimento.py --stage final`. Esto reproduce el análisis fijado, no una nueva validación externa. `Rscript verificar_resultados.R <carpeta_del_experimento>` verifica la aritmética. Los modelos serializados solo deben abrirse si proceden de este paquete de confianza.

El archivo manuscript.tex, references.bib, sn-jnl.cls, sn-mathphys-ay.bst y las cuatro figuras deben permanecer juntos para compilar. El PDF se revisa visualmente después de la compilación.
'''
(O/'LEEME_RESULTADOS.md').write_text(summary,encoding='utf8')
print('Manuscript and four figures generated.')
