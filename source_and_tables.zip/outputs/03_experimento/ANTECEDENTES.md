# Antecedentes y límite de la contribución

Revisión dirigida, no sistemática. Las fichas y resúmenes editoriales se consultaron el 3 de octubre de 2026. Las afirmaciones de prioridad requieren una revisión más amplia y lectura completa de los artículos próximos antes del envío.

| Referencia | Aporte pertinente | Consecuencia para nuestro trabajo |
|---|---|---|
| [Zhang et al. (2017)](https://doi.org/10.1098/rspa.2017.0457) | Artículo de origen asociado a los datos de Beijing. | Citar el contexto y atribuir el conjunto; el estudio actual es secundario. |
| [Gibbs y Candès (2021)](https://papers.neurips.cc/paper_files/paper/2021/hash/0d441de75945e5acbc865406fc9a2559-Abstract.html) | Adaptación de la inferencia conformal bajo cambios de distribución. | No presentar la adaptación de intervalos como una idea nueva. |
| [Zaffran et al. (2022)](https://proceedings.mlr.press/v162/zaffran22a.html) | Evaluación y agregación de métodos adaptativos para series temporales. | La comparación temporal justa y los métodos adaptativos tienen antecedentes consolidados. |
| [Xu y Xie (2023)](https://proceedings.mlr.press/v202/xu23r.html) | SPCI modela cuantiles de errores futuros usando dependencia temporal. | La ventana móvil simple implementada aquí no es SPCI ni demuestra superioridad frente a él. |
| [Zaffran et al. (2023)](https://proceedings.mlr.press/v202/zaffran23a.html) | Cuantificación conformal con covariables faltantes y patrones de ausencia. | Ajustar la calibración a datos incompletos tampoco es una novedad general. |
| [Romano et al. (2019)](https://proceedings.neurips.cc/paper/2019/hash/5103c3584b063c431bd1268e9b5e76fb-Abstract.html) | Regresión por cuantiles conformalizada. | Es un comparador relevante para una ampliación; no se ha ejecutado en este experimento. |
| [Gneiting y Raftery (2007)](https://doi.org/10.1198/016214506000001437) | Reglas de puntuación y evaluación conjunta de cobertura y amplitud. | Evaluar con interval score, no premiar cobertura conseguida con intervalos arbitrariamente anchos. |

También se localizaron [E-STGCN](https://arxiv.org/abs/2411.12258), [incertidumbre con datos incompletos de calidad del aire](https://arxiv.org/abs/2511.02175) y [predicción entre ubicaciones bajo datos faltantes](https://www.mdpi.com/2224-2708/15/4/52). La lectura completa, disponibilidad de código y comparabilidad de estos trabajos deben verificarse antes de afirmar una brecha editorial.

El aporte que sí puede evaluarse con el experimento actual es un procedimiento reproducible que retrasa simultáneamente las covariables de PM2.5 y la disponibilidad de los errores usados para recalibrar. Se entrega un diagnóstico explícito que ignora esa segunda restricción para cuantificar cómo cambia el resultado, sin asumir de antemano que lo mejora. Se trata de una evaluación aplicada de métodos existentes, no de un nuevo algoritmo conformal.
