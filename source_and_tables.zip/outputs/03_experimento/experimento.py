"""Run development selection and a prespecified delayed-observation experiment.
python experimento.py --stage development
python experimento.py --stage final
"""
import os
os.environ.setdefault('OMP_NUM_THREADS','2')
os.environ.setdefault('OPENBLAS_NUM_THREADS','2')
from pathlib import Path
import argparse, json, time, hashlib, platform
import numpy as np
import pandas as pd
import sklearn
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.linear_model import Ridge
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from threadpoolctl import threadpool_limits
import joblib

ROOT=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--stage',choices=['development','final'],required=True)
ap.add_argument('--data',type=Path,default=ROOT.parent/'02_datos_estudio')
a=ap.parse_args(); DATA=a.data
for name in ['tables','predictions','models']: (ROOT/name).mkdir(exist_ok=True)
preds=json.loads((DATA/'manifest.json').read_text(encoding='utf8'))['predictors_allowlist']
protocol_sha=hashlib.sha256((ROOT/'PROTOCOLO.md').read_bytes()).hexdigest()
threads=threadpool_limits(limits=2)
SEED=20261003

def read(label):
    return pd.read_csv(DATA/f'data/{label}_24h.csv.gz',parse_dates=['datetime','target_time']).sort_values(['datetime','station']).reset_index(drop=True)

class Encoder:
    def fit(self,d):
        self.cats={c:sorted(d[c].dropna().unique()) for c in ['station','wd']}
        self.cols=self.transform(d).columns.tolist();return self
    def transform(self,d):
        z=d[preds].copy()
        for c,cat in self.cats.items():z[c]=pd.Categorical(z[c],categories=cat)
        z=pd.get_dummies(z,columns=['station','wd'],dummy_na=True,dtype=float)
        return z.astype(float)

def hgb(leaves,iters):
    return HistGradientBoostingRegressor(loss='absolute_error',learning_rate=.05,max_leaf_nodes=leaves,max_iter=iters,
        min_samples_leaf=40,l2_regularization=1,early_stopping=False,random_state=SEED)

def clip(y):return np.maximum(0,np.asarray(y))
def errors(y,p):return {'mae':float(np.mean(abs(y-p))),'rmse':float(np.sqrt(np.mean((y-p)**2)))}

def reference_fit(d):
    # Only observed training targets, available before the training cutoff.
    z=d.assign(target_hour=d.target_time.dt.hour)
    return (z.groupby('station').target_pm25_24h.median(),z.groupby(['station','target_hour']).target_pm25_24h.mean(),float(z.target_pm25_24h.median()))
def reference_predict(d,ref):
    med,clim,global_med=ref
    fallback=d.station.map(med).fillna(global_med).to_numpy()
    p=d.latest_pm25.to_numpy() if 'latest_pm25' in d else d['PM2.5'].to_numpy()
    persistence=np.where(np.isnan(p),fallback,p)
    keys=pd.MultiIndex.from_arrays([d.station,d.target_time.dt.hour])
    season=clim.reindex(keys).to_numpy();season=np.where(np.isnan(season),fallback,season)
    return {'persistence':clip(persistence),'station_hour_mean':clip(season)}

panel=None
def get_panel():
    global panel
    if panel is None:
        panel=pd.read_csv(DATA/'data/panel_preservado.csv.gz',usecols=['station','datetime','PM2.5'],parse_dates=['datetime']).sort_values(['station','datetime'])
    return panel

def delayed(d,lag):
    p=get_panel().copy();g=p.groupby('station',sort=False)['PM2.5']
    last_t=p.datetime.where(p['PM2.5'].notna()).groupby(p.station).ffill()
    past_t=last_t.groupby(p.station).shift(lag)
    f=pd.DataFrame({'station':p.station,'datetime':p.datetime,
       'latest_pm25':g.transform(lambda s:s.ffill().shift(lag)),
       'pm25_age_hours':(p.datetime-past_t).dt.total_seconds()/3600})
    if lag:
        f['PM2.5']=np.nan;f['PM2.5_missing']=1
        for k in [1,3,6,12,24,48,168]:
            if k<lag:f[f'pm25_lag_{k}h']=np.nan
        for window in [24,168]:
            for stat in ['mean','std','count']:
                name=f'pm25_{stat}_{window}h'
                if lag>=window:f[name]=0.0 if stat=='count' else np.nan
                else:f[name]=g.transform(lambda s:getattr(s.shift(lag).rolling(window-lag,min_periods=1),stat)())
    updates=[c for c in f if c not in ['station','datetime']]
    out=d.drop(columns=[c for c in updates if c in d]).merge(f,on=['station','datetime'],how='left',validate='one_to_one')
    assert len(out)==len(d)
    # Independent checks against the exact allowed interval for 12 origins.
    for row in out.sample(12,random_state=SEED).itertuples():
        q=p.loc[p.station.eq(row.station)]
        for w in [24,168]:
            v=q.loc[q.datetime.between(row.datetime-pd.Timedelta(hours=w-1),row.datetime-pd.Timedelta(hours=lag)),'PM2.5'] if lag<w else pd.Series([],dtype=float)
            np.testing.assert_allclose(getattr(row,f'pm25_mean_{w}h'),v.mean(),equal_nan=True)
    return out

if a.stage=='development':
    dev=delayed(read('development'),0)
    rows=[]
    folds=[('2014-03-01','2014-07-01'),('2014-07-01','2014-11-01'),('2014-11-01','2015-03-01')]
    for fold,(start,end) in enumerate(folds,1):
        train=dev[dev.target_time.lt(start)].copy()
        val=dev[dev.datetime.ge(start)&dev.target_time.lt(end)].copy()
        enc=Encoder().fit(train);X=enc.transform(train);V=enc.transform(val); y=train.target_pm25_24h;yv=val.target_pm25_24h.to_numpy()
        for model,p in reference_predict(val,reference_fit(train)).items():rows.append({'fold':fold,'model':model,'n_train':len(train),'n_val':len(val),**errors(yv,p)})
        for alpha in [1.,10.,100.]:
            model=make_pipeline(SimpleImputer(strategy='median',keep_empty_features=True),StandardScaler(),Ridge(alpha=alpha))
            model.fit(X,y);r={'fold':fold,'model':f'ridge_{alpha:g}','n_train':len(train),'n_val':len(val),**errors(yv,clip(model.predict(V)))};rows.append(r);print(r,flush=True)
        for leaves,iters in [(15,100),(31,100),(31,200)]:
            model=hgb(leaves,iters);model.fit(X,y)
            r={'fold':fold,'model':f'hgb_{leaves}_{iters}','n_train':len(train),'n_val':len(val),**errors(yv,clip(model.predict(V)))};rows.append(r);print(r,flush=True)
        pd.DataFrame(rows).to_csv(ROOT/'tables/cv_development.csv',index=False)
    cv=pd.DataFrame(rows);summary=cv.groupby('model')[['mae','rmse']].mean().sort_values('mae');summary.to_csv(ROOT/'tables/cv_summary.csv')
    chosen={fam:summary.loc[summary.index.str.startswith(fam)].mae.idxmin() for fam in ['ridge','hgb']}
    chosen.update(protocol_sha256=protocol_sha,seed=SEED,criterion='unweighted mean fold MAE',sklearn=sklearn.__version__)
    (ROOT/'selection.json').write_text(json.dumps(chosen,indent=2),encoding='utf8');print(chosen,flush=True)
    raise SystemExit

selection=json.loads((ROOT/'selection.json').read_text())
assert selection['protocol_sha256']==protocol_sha,'Protocol changed after development selection.'
dev=delayed(read('development'),0);cal=read('calibration');test=read('test')
enc=Encoder().fit(dev);X=enc.transform(dev);y=dev.target_pm25_24h
_,leaves,iters=selection['hgb'].split('_');model=hgb(int(leaves),int(iters));model.fit(X,y)
ridge=make_pipeline(SimpleImputer(strategy='median',keep_empty_features=True),StandardScaler(),Ridge(alpha=float(selection['ridge'].split('_')[1])))
ridge.fit(X,y);ref=reference_fit(dev)
joblib.dump({'hgb':model,'ridge':ridge,'encoder':enc,'reference':ref},ROOT/'models/fitted.joblib')
calcut=pd.Timestamp('2016-03-01')-pd.Timedelta(hours=168)
cache={};pointrows=[]
for lag in [0,6,24,72,168]:
    c=delayed(cal,lag);t=delayed(test,lag)
    pc=clip(model.predict(enc.transform(c)));pt=clip(model.predict(enc.transform(t)))
    cache[lag]={'cal':c,'test':t,'pc':pc,'pt':pt,'rescal':abs(c.target_pm25_24h.to_numpy()-pc)}
    refs=reference_predict(t,ref);refs.update(hgb=pt,ridge=clip(ridge.predict(enc.transform(t))))
    for name,pred in refs.items():pointrows.append({'delay_h':lag,'model':name,'n':len(t),**errors(t.target_pm25_24h.to_numpy(),pred)})
    print('Point predictions prepared, delay',lag,flush=True)
pd.DataFrame(pointrows).to_csv(ROOT/'tables/point_metrics.csv',index=False)

def quantile(scores,alpha):
    n=len(scores);k=int(np.ceil((n+1)*(1-alpha)))
    assert 0<k<=n
    return float(np.partition(np.asarray(scores),k-1)[k-1])

def rolling_q(c,t,pc,pt,lag,alpha):
    times=pd.concat([c.target_time,t.target_time],ignore_index=True).to_numpy(dtype='datetime64[ns]')
    scores=np.r_[abs(c.target_pm25_24h.to_numpy()-pc),abs(t.target_pm25_24h.to_numpy()-pt)]
    sort=np.argsort(times);times=times[sort];scores=scores[sort]
    result=np.zeros(len(t));days=t.datetime.dt.floor('D')
    for day,indices in t.groupby(days).groups.items():
        cutoff=day-pd.Timedelta(hours=lag)
        lo=np.searchsorted(times,np.datetime64(cutoff-pd.Timedelta(days=30)),side='right')
        hi=np.searchsorted(times,np.datetime64(cutoff),side='right')
        assert hi>lo and times[hi-1]<=np.datetime64(cutoff)
        result[np.asarray(list(indices))]=quantile(scores[lo:hi],alpha)
    return result

metricrows=[];dayrows=[];subrows=[];primary=None
for lag,z in cache.items():
    c,t,pc,pt=z['cal'],z['test'],z['pc'],z['pt']; y=t.target_pm25_24h.to_numpy()
    record=t[['station','datetime','target_time','target_pm25_24h']].copy();record['prediction']=pt
    for alpha in [.1,.05]:
        zero=cache[0];q0=quantile(zero['rescal'][zero['cal'].target_time.lt(calcut)],alpha)
        qmatch=quantile(z['rescal'][c.target_time.lt(calcut)],alpha)
        qs={'static_unmatched':np.full(len(t),q0),'static_matched':np.full(len(t),qmatch),
            'rolling_valid':rolling_q(c,t,pc,pt,lag,alpha),
            'rolling_ignores_delay_DIAGNOSTIC':rolling_q(c,t,pc,pt,0,alpha)}
        scores_saved={}
        for method,q in qs.items():
            lower=np.maximum(0,pt-q);upper=pt+q;width=upper-lower;cover=(y>=lower)&(y<=upper)
            score=width+2/alpha*((lower-y)*(y<lower)+(y-upper)*(y>upper))
            scores_saved[method]=score
            record[f'{method}_lower_{1-alpha:.2f}']=lower;record[f'{method}_upper_{1-alpha:.2f}']=upper
            metricrows.append({'delay_h':lag,'nominal':1-alpha,'method':method,'n':len(t),
                              'coverage':cover.mean(),'width':width.mean(),'interval_score':score.mean()})
            tmp=pd.DataFrame({'day':t.datetime.dt.floor('D'),'station':t.station,'quarter':t.datetime.dt.to_period('Q').astype(str),'n':1,'covered':cover.astype(int),'width':width,'interval_score':score})
            ag=tmp.groupby('day')[['n','covered','width','interval_score']].sum().reset_index()
            ag['delay_h']=lag;ag['nominal']=1-alpha;ag['method']=method;dayrows.append(ag)
            for group in ['station','quarter']:
                for value,s in tmp.groupby(group):
                    subrows.append({'delay_h':lag,'nominal':1-alpha,'method':method,'group':group,'value':value,
                      'n':len(s),'coverage':s.covered.mean(),'width':s.width.mean(),'interval_score':s.interval_score.mean()})
        if lag==72 and alpha==.1:
            primary=pd.DataFrame({'day':t.datetime.dt.floor('D'),'difference':scores_saved['rolling_valid']-scores_saved['static_unmatched'],'n':1}).groupby('day').sum()
    record.to_csv(ROOT/f'predictions/delay_{lag}h.csv.gz',index=False,compression={'method':'gzip','compresslevel':1,'mtime':0})
    print('Intervals complete, delay',lag,flush=True)
pd.DataFrame(metricrows).to_csv(ROOT/'tables/interval_metrics.csv',index=False)
pd.concat(dayrows,ignore_index=True).to_csv(ROOT/'tables/daily_sufficient_statistics.csv',index=False)
pd.DataFrame(subrows).to_csv(ROOT/'tables/subgroup_metrics.csv',index=False)
primary.to_csv(ROOT/'tables/primary_daily_paired_differences.csv')
rng=np.random.default_rng(SEED);N=len(primary);vals=primary.difference.to_numpy();counts=primary.n.to_numpy();boots=[]
for length in [7,14,28]:
    samples=[]
    for _ in range(1000):
        starts=rng.integers(0,N,size=int(np.ceil(N/length)))
        idx=((starts[:,None]+np.arange(length))%N).ravel()[:N]
        samples.append(vals[idx].sum()/counts[idx].sum())
    low,high=np.quantile(samples,[.025,.975]);boots.append({'block_days':length,'replicates':1000,'estimate':vals.sum()/counts.sum(),'lower95':low,'upper95':high})
pd.DataFrame(boots).to_csv(ROOT/'tables/primary_bootstrap.csv',index=False)
metadata={'protocol_sha256':protocol_sha,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'selection':selection,
 'python':platform.python_version(),'sklearn':sklearn.__version__,'numpy':np.__version__,'pandas':pd.__version__,
 'static_calibration_targets_before':str(calcut),'test_opened_for_final_evaluation':True,'scope':'single-city retrospective semisynthetic delay benchmark, no external validation',
 'methods_not_implemented':['ACI','EnbPI','SPCI','CP-MDA'],'seed':SEED,'cv_reference':'tables/cv_development.csv'}
(ROOT/'RUN_MANIFEST.json').write_text(json.dumps(metadata,indent=2),encoding='utf8')
print(pd.DataFrame(boots).to_string(index=False),flush=True)
