# Protocolo de evaluación, versión 1

Fijado antes de ejecutar la comparación de modelos o abrir resultados predictivos de prueba. Es un protocolo local, no un prerregistro público. Los conteos y las ausencias de toda la base ya se auditaron en la etapa de preparación.

## Pregunta y alcance

Evaluar empíricamente cómo afecta el retraso de entrega de PM2.5 a la predicción a 24 horas y a la calibración de intervalos. Es un estudio retrospectivo y semisintético en Beijing, sin atribución causal ni propuesta de un nuevo teorema conformal. Las duraciones de retraso de 0, 6, 24, 72 y 168 horas son escenarios de estrés; no se afirma que sean latencias medidas de la red original. El caso de 0 h conserva todas las ausencias naturales.

Solo se retrasa el canal PM2.5. Los demás contaminantes y variables meteorológicas se suponen disponibles al origen, conservando sus ausencias. No representa una caída de toda la estación. Para un retraso d, se oculta PM2.5 en (t-d,t], se reconstruyen rezagos, promedios, conteos y antigüedad, y las respuestas de pronósticos anteriores solo pueden actualizar los intervalos una vez llegado su tiempo de medición más d.

## Desarrollo y modelo

Desarrollo 2013-03 a 2015-02; calibración 2015-03 a 2016-02; prueba 2016-03 a 2017-02. Se conserva la purga de respuestas que crucen fronteras y la semana inicial para construir historia.

Validación de origen creciente dentro de desarrollo: marzo-junio de 2014, julio-octubre de 2014 y noviembre de 2014-febrero de 2015. Entrenamiento en todo el pasado disponible con tiempo de respuesta anterior al inicio de cada ventana. Preprocesamiento ajustado exclusivamente en el entrenamiento correspondiente.

Comparar persistencia con último PM2.5 conocido (mediana de entrenamiento por estación como respaldo), media histórica por estación y hora de respuesta, Ridge (alpha 1, 10, 100) e HistGradientBoostingRegressor con pérdida absoluta, learning rate 0.05, min_samples_leaf 40, l2_regularization 1 y configuraciones (15 hojas,100 iteraciones), (31,100), (31,200). Sin parada temprana aleatoria. Elegir configuración de cada familia mediante MAE medio de las tres ventanas. Las predicciones negativas se truncan en cero. HGB será el predictor fijo de la comparación principal de intervalos, aunque otra familia tenga mejor MAE; se reportarán todas las referencias.

## Intervalos y pruebas

Residuos absolutos y niveles nominales de 90 % y 95 %. Cuantil empírico con rango ceil((n+1)(1-alpha)), acotado solo cuando existen suficientes observaciones. Intervalos simétricos alrededor del predictor con límite inferior truncado en cero.

Comparar: (1) calibración estática sin retraso aplicada a todos los escenarios; (2) calibración estática ajustada al retraso; (3) calibración móvil ajustada al retraso, con ventana de 30 días y actualización diaria. La calibración estática usa respuestas anteriores a 2016-03-01 menos 168 horas, una exclusión común que permite emitir el primer pronóstico bajo todos los escenarios. La calibración móvil usa solo respuestas con tiempo de medición anterior o igual al inicio del día menos d. Al tener horizonte 24 h, eso corresponde a orígenes de al menos 24+d horas atrás. Se agrupan estaciones al estimar cuantiles.

Como diagnóstico separado se calcula una actualización móvil que ignora el retraso de entrega del objetivo. Es inviable para d>0 y debe etiquetarse como tal, nunca confundirse con un método operativo. No se requiere que favorezca al modelo.

Métricas: MAE, RMSE, cobertura, amplitud e interval score. Se reportan resultados por escenario, estación y trimestre. Comparación primaria: diferencia de interval score al 90 % entre calibración móvil válida y calibración estática sin retraso para d=72 h. Una diferencia negativa favorece al método móvil. El resto de comparaciones es descriptivo/secundario; no se escogerá el escenario más favorable como resultado principal.

Incertidumbre: bootstrap circular por bloques de días con todas las estaciones juntas, 1 000 réplicas, bloques de 7 días y sensibilidad de 14 y 28 días. Estimadores ponderados por número de objetivos observados. Los intervalos bootstrap describen incertidumbre condicionada a los modelos ya ajustados y a esta red, no incorporan reajuste de modelos ni representan ciudades independientes. No usar p-valores de horas independientes.

La dependencia temporal y espacial, los cambios de distribución y las ausencias impiden atribuir automáticamente las garantías clásicas bajo intercambiabilidad. La interpretación será empírica. Se conservarán resultados desfavorables y todos los modelos especificados.

## Límites para publicación

La contribución potencial es una evaluación reproducible que respeta simultáneamente la disponibilidad de covariables y del error de calibración. No se afirmará originalidad del método de calibración ni superioridad frente a EnbPI, SPCI, ACI o CP-MDA, que no forman parte de esta primera comparación. Un envío competitivo requerirá ampliar comparadores, validar en otra red y verificar la revista/categoría Q1. La autoría y las declaraciones personales quedan pendientes de datos reales del equipo.
