"""Post-review factorial and random-assignment checks. No model refitting."""
from pathlib import Path
import ast,json,hashlib,sys
import numpy as np
import pandas as pd
import joblib
from scipy.stats import wasserstein_distance
from threadpoolctl import threadpool_limits
threadpool_limits(2)
OUT=Path(__file__).resolve().parent; ROOT=OUT.parent/'05_revision'; OLD=OUT.parent/'03_experimento'; DATA=OUT.parent/'02_datos_estudio'
for f in ['tables','predictions','cache']: (OUT/f).mkdir(exist_ok=True)
SEED=20261005;panel=None;preds=json.loads((DATA/'manifest.json').read_text(encoding='utf8'))['predictors_allowlist']
for file,names in [(OLD/'experimento.py',{'Encoder','read','get_panel','delayed','clip','quantile'}),(ROOT/'revision.py',{'SafeEncoder','rolling','get_q'})]:
 tree=ast.parse(file.read_text(encoding='utf8'));exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in names],type_ignores=[]),str(file),'exec'))
def save(rows,name):pd.DataFrame(rows).to_csv(OUT/'tables'/name,index=False)
def val(y,l,u,a):return (y>=l)&(y<=u),u-l,u-l+2/a*(np.maximum(l-y,0)+np.maximum(y-u,0))
def metric(y,l,u,a):
 c,w,s=val(y,l,u,a);return dict(n=len(y),covered_n=int(c.sum()),coverage=c.mean(),width=w.mean(),interval_score=s.mean())
def fast(c,t,pc,pt,mapping):
 """Same arrival/day rules as revision.rolling, sorted once by arrival."""
 station=np.r_[c.station.to_numpy(),t.station.to_numpy()];codes=pd.Categorical(station,categories=sorted(mapping)).codes
 ca=(c.target_time+pd.to_timedelta(c.station.map(mapping),unit='h')).to_numpy();ta=(t.target_time+pd.to_timedelta(t.station.map(mapping),unit='h')).to_numpy()
 arrival=np.r_[ca,ta];res=np.abs(np.r_[c.target_pm25_24h.to_numpy()-pc,t.target_pm25_24h.to_numpy()-pt]);order=np.argsort(arrival);arrival=arrival[order];res=res[order];codes=codes[order]
 y=t.target_pm25_24h.to_numpy();tc=pd.Categorical(t.station,categories=sorted(mapping)).codes
 bounds={(kind,a):(np.full(len(t),np.nan),np.full(len(t),np.nan)) for kind in ['global','station','equal_station','ADH'] for a in [.1,.05]}
 states={a:a for a in [.1,.05]};last=None
 for day,ix in t.groupby(t.datetime.dt.floor('D')).groups.items():
  ix=np.asarray(ix);now=np.datetime64(day);left=np.searchsorted(arrival,now-np.timedelta64(30,'D'),side='right');right=np.searchsorted(arrival,now,side='right');rr=res[left:right];ss=codes[left:right];assert len(rr)>0
  ar=(ta<=now)&(t.datetime.to_numpy()<now)
  if last is not None:ar&=ta>last
  vi=np.flatnonzero(ar);sortedix=np.argsort(rr);vr=rr[sortedix];ws=1/np.bincount(ss,minlength=len(mapping))[ss[sortedix]];cum=np.cumsum(ws)/ws.sum()
  for a in [.1,.05]:
   if len(vi):
    l,u=bounds['ADH',a];assert np.isfinite(l[vi]).all();miss=((y[vi]<l[vi])|(y[vi]>u[vi])).mean();states[a]=float(np.clip(states[a]+.01*(a-miss),.001,.5))
   for kind in ['global','station','equal_station','ADH']:
    if kind=='global':q=quantile(rr,a)
    elif kind=='ADH':q=quantile(rr,states[a])
    elif kind=='equal_station':q=vr[min(np.searchsorted(cum,1-a),len(vr)-1)]
    else:
     qs=np.array([quantile(rr[ss==k],a) for k in range(len(mapping))]);q=qs[tc[ix]]
    l,u=bounds[kind,a];l[ix]=np.maximum(0,pt[ix]-q);u[ix]=pt[ix]+q
  last=now
 return bounds
cal=read('calibration');test=read('test');stations=sorted(test.station.unique());cut=cal.target_time.lt('2016-02-23').to_numpy();assert cut.sum()==101012
cache={};audit=[]
for d in [0,6,24,72,168]:
 cp=OUT/f'cache/point_predictions_{d}h.npz'
 if cp.exists():
  z=np.load(cp);cache[d]={k:z[k] for k in z.files};continue
 c=delayed(cal,d);t=delayed(test,d);fixed=joblib.load(OLD/'models/fitted.joblib');ad=joblib.load(ROOT/f'models/adapted_{d}h.joblib')
 cache[d]={}
 old=pd.read_csv(ROOT/f'predictions/delay_{d}h.csv.gz',usecols=['prediction_fixed','prediction_adapted'])
 for name,e,m in [('fixed',fixed['encoder'],fixed['hgb']),('adapted',ad['encoder'],ad['model'])]:
  pc=clip(m.predict(e.transform(c)));pt=clip(m.predict(e.transform(t)));err=np.max(np.abs(pt-old['prediction_'+name].to_numpy()));assert err<1e-10
  cache[d]['cal_'+name]=pc;cache[d]['test_'+name]=pt;audit.append(dict(delay_h=d,predictor=name,max_stored_prediction_error=err))
 np.savez_compressed(cp,**cache[d]);print('Predictions verified',d,flush=True)
if audit:save(audit,'point_prediction_audit.csv')
metrics=[];contrasts=[];checks=[];dailyrows=[]
day=test.datetime.dt.floor('D');ud=pd.date_range(day.min(),day.max());dc=ud.get_indexer(day);N=len(ud);counts=np.bincount(dc,minlength=N);W={}
for L in [7,14,28]:
 rng=np.random.default_rng(20261007+L);weights=np.zeros((10000,N),dtype=np.int16)
 for b in range(10000):
  ix=((rng.integers(N,size=int(np.ceil(N/L)))[:,None]+np.arange(L))%N).ravel()[:N];weights[b]=np.bincount(ix,minlength=N)
 W[L]=weights
for d in [0,6,24,72,168]:
 y=test.target_pm25_24h.to_numpy();record=test[['station','datetime','target_time','target_pm25_24h']].copy();scores={}
 old=pd.read_csv(OLD/f'predictions/delay_{d}h.csv.gz');ext=pd.read_csv(ROOT/f'predictions/delay_{d}h.csv.gz')
 for predictor in ['fixed','adapted']:
  pc=cache[d]['cal_'+predictor];pt=cache[d]['test_'+predictor];record['prediction_'+predictor]=pt
  for a in [.1,.05]:
   for method in ['static','rolling','ADH']:
    if method=='static':q=quantile(np.abs(cal.target_pm25_24h.to_numpy()-pc)[cut],a);l=np.maximum(0,pt-q);u=pt+q
    else:l,u,_,_=rolling(cal,test,pc,pt,{s:d for s in stations},a,adaptive=method=='ADH')
    name=f'{predictor}_{method}';level=f'{1-a:.2f}';record[f'{name}_lower_{level}']=l;record[f'{name}_upper_{level}']=u
    scores[predictor,method,a]=val(y,l,u,a)[2];metrics.append(dict(delay_h=d,predictor=predictor,calibrator=method,nominal=1-a,**metric(y,l,u,a)))
    if predictor=='fixed':
     ref=ext if method=='ADH' else old;key={'static':'static_matched','rolling':'rolling_valid','ADH':'ACI_delayed_projected'}[method]
     error=max(np.max(np.abs(l-ref[f'{key}_lower_{level}'])),np.max(np.abs(u-ref[f'{key}_upper_{level}'])));assert error<1e-10;checks.append(dict(delay_h=d,method=method,nominal=1-a,max_bound_error=error))
 for a in [.1,.05]:
  ds={f'adapted_minus_fixed_{m}':scores['adapted',m,a]-scores['fixed',m,a] for m in ['static','rolling','ADH']}
  for p in ['fixed','adapted']:
   for m in ['rolling','ADH']:ds[f'{p}_{m}_minus_static']=scores[p,m,a]-scores[p,'static',a]
  for m in ['rolling','ADH']:ds[f'interaction_{m}_vs_static']=ds[f'adapted_{m}_minus_static']-ds[f'fixed_{m}_minus_static']
  for name,diff in ds.items():
   sums=np.bincount(dc,weights=diff,minlength=N)
   dailyrows.extend(dict(delay_h=d,nominal=1-a,contrast=name,day=str(x.date()),sum_difference=v,n=int(n)) for x,v,n in zip(ud,sums,counts))
   for L,weights in W.items():
    boot=(weights@sums)/(weights@counts);lo,hi=np.quantile(boot,[.025,.975]);contrasts.append(dict(delay_h=d,nominal=1-a,contrast=name,block_days=L,estimate=diff.mean(),lower95=lo,upper95=hi,replicates=10000,seed=20261007+L))
 record.to_csv(OUT/f'predictions/factorial_{d}h.csv.gz',index=False,compression={'method':'gzip','compresslevel':1,'mtime':0})
 save(metrics,'factorial_metrics.csv');save(contrasts,'factorial_contrasts.csv');save(checks,'fixed_cells_audit.csv');print('Factorial completed',d,flush=True)
save(dailyrows,'factorial_daily_contrasts.csv')
# Exact coverage counts and membership, not just rounded percentages.
z=pd.read_csv(ROOT/'predictions/delay_72h.csv.gz');y=z.target_pm25_24h.to_numpy();rows=[];dis=[]
for a in [.1,.05]:
 membership={}
 for m in ['rolling_global','rolling_station','rolling_equal_station']:
  l=z[f'{m}_lower_{1-a:.2f}'].to_numpy();u=z[f'{m}_upper_{1-a:.2f}'].to_numpy();cov=val(y,l,u,a)[0];membership[m]=cov;rows.append(dict(method=m,nominal=1-a,**metric(y,l,u,a)))
 for m in ['rolling_station','rolling_equal_station']:
  x=membership['rolling_global'];b=membership[m];dis.append(dict(nominal=1-a,method=m,gained=int((b&~x).sum()),lost=int((x&~b).sum()),disagree=int((x!=b).sum()),net=int(b.sum()-x.sum())))
save(rows,'coverage_exact.csv');save(dis,'coverage_disagreements.csv')
# Descriptive shift diagnostics; no iid p values.
shift=[];summary=[]
for variable in ['response','abs_residual_fixed','abs_residual_adapted']:
 x=cal.target_pm25_24h.to_numpy();y=test.target_pm25_24h.to_numpy()
 if variable!='response':
  pred=variable.replace('abs_residual_','');x=np.abs(x-cache[72]['cal_'+pred]);y=np.abs(y-cache[72]['test_'+pred])
 for group in ['all']+[f'month_{i:02d}' for i in range(1,13)]:
  k=None if group=='all' else int(group[-2:]);xx=x if k is None else x[cal.datetime.dt.month.eq(k)];yy=y if k is None else y[test.datetime.dt.month.eq(k)]
  sx=np.sort(xx);sy=np.sort(yy);grid=np.unique(np.r_[sx,sy]);ks=np.max(np.abs(np.searchsorted(sx,grid,side='right')/len(sx)-np.searchsorted(sy,grid,side='right')/len(sy)))
  shift.append(dict(variable=variable,group=group,calibration_n=len(xx),test_n=len(yy),calibration_mean=xx.mean(),test_mean=yy.mean(),standardized_mean_difference=(yy.mean()-xx.mean())/np.sqrt((xx.var()+yy.var())/2),ks_distance=ks,wasserstein=wasserstein_distance(xx,yy),calibration_q90=np.quantile(xx,.9),test_q90=np.quantile(yy,.9)))
 for period,frame,v in [('calibration',cal,x),('test',test,y)]:
  for quarter in ['all']+sorted(frame.datetime.dt.to_period('Q').astype(str).unique()):
   vv=v if quarter=='all' else v[frame.datetime.dt.to_period('Q').astype(str).eq(quarter)]
   summary.append(dict(variable=variable,period=period,quarter=quarter,n=len(vv),mean=vv.mean(),median=np.median(vv),q90=np.quantile(vv,.9),q95=np.quantile(vv,.95),q99=np.quantile(vv,.99)))
save(shift,'shift_distances.csv');save(summary,'shift_quantiles.csv')
# Random balanced assignments; report the distribution of metrics, not pooled pseudo-replication.
rng=np.random.default_rng(20261007);mappingrows=[];randomrows=[];fastchecks=[]
for rep in range(41):
 ds=np.array([6,24,72,168]*3);ds=ds if rep==0 else rng.permutation(ds);mapping=dict(zip(stations,ds))
 mappingrows.extend(dict(assignment=rep,station=s,delay_h=int(d)) for s,d in mapping.items())
 pc=np.empty(len(cal));pt=np.empty(len(test))
 for s,d in mapping.items():
  ci=cal.station.eq(s).to_numpy();ti=test.station.eq(s).to_numpy();pc[ci]=cache[d]['cal_fixed'][ci];pt[ti]=cache[d]['test_fixed'][ti]
 bb=fast(cal,test,pc,pt,mapping);y=test.target_pm25_24h.to_numpy()
 for (kind,a),(l,u) in bb.items():
  randomrows.append(dict(assignment=rep,method=kind,nominal=1-a,**metric(y,l,u,a)))
  if rep in [0,1]:
   ol,ou,_,_=rolling(cal,test,pc,pt,mapping,a,kind='global' if kind=='ADH' else kind,adaptive=kind=='ADH');err=max(np.max(np.abs(l-ol)),np.max(np.abs(u-ou)));assert err<1e-10;fastchecks.append(dict(assignment=rep,method=kind,nominal=1-a,max_bound_error=err))
 if rep%5==0: print('Heterogeneous assignment',rep,'of 40',flush=True)
save(mappingrows,'random_delay_assignments.csv');save(randomrows,'random_assignment_metrics.csv');save(fastchecks,'optimized_loop_audit.csv')
summary=[];df=pd.DataFrame(randomrows)
for (m,n),z in df[df.assignment>0].groupby(['method','nominal']):
 for met in ['coverage','width','interval_score']:
  v=z[met];summary.append(dict(method=m,nominal=n,metric=met,assignments=40,mean=v.mean(),sd=v.std(),minimum=v.min(),q025=v.quantile(.025),q975=v.quantile(.975),maximum=v.max(),alphabetical=df[(df.assignment==0)&(df.method==m)&(df.nominal==n)][met].iloc[0]))
save(summary,'random_assignment_summary.csv')
(OUT/'RUN_MANIFEST.json').write_text(json.dumps({'status':'complete','analysis':'post-review exploratory factorial and assignment sensitivity','model_refits':0,'factorial_rows':len(metrics),'paired_contrasts':len(contrasts),'random_assignments':40,'random_seed':20261007,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'plan_sha256':hashlib.sha256((OUT/'PLAN_EXPLORATORIO.md').read_bytes()).hexdigest()},indent=2))
print('ALL ADDITIONAL ANALYSES COMPLETE',flush=True)
