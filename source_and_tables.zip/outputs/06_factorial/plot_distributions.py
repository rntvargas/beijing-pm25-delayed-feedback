from pathlib import Path
import numpy as np,pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
P=Path('outputs/04_manuscrito_springer');F=Path('outputs/06_factorial')
labels={'response':'Response','abs_residual_fixed':'Fixed absolute error','abs_residual_adapted':'Adapted absolute error'}
cal=pd.read_csv('outputs/02_datos_estudio/data/calibration_24h.csv.gz',usecols=['target_pm25_24h']);test=pd.read_csv('outputs/02_datos_estudio/data/test_24h.csv.gz',usecols=['target_pm25_24h']);cache=np.load(F/'cache/point_predictions_72h.npz')
plt.rcParams.update({'font.size':9});fig,axs=plt.subplots(1,3,figsize=(10.5,3.0),layout='constrained')
for ax,(name,label) in zip(axs,labels.items()):
 x=cal.target_pm25_24h.to_numpy();y=test.target_pm25_24h.to_numpy()
 if name!='response':pred=name.replace('abs_residual_','');x=np.abs(x-cache['cal_'+pred]);y=np.abs(y-cache['test_'+pred])
 for v,l,col in [(x,'Calibration','#267394'),(y,'Test','#c26a24')]:
  v=np.sort(v);inds=np.unique(np.linspace(0,len(v)-1,2500).astype(int));ax.plot(v[inds],(inds+1)/len(v),label=l,color=col,lw=1.5)
 ax.set_xlim(0,np.quantile(np.r_[x,y],.99));ax.set_ylim(0,1);ax.set_title(label);ax.set_xlabel(r'$\mu$g/m$^3$');ax.grid(alpha=.2)
axs[0].set_ylabel('Empirical cumulative probability');axs[-1].legend(loc='lower right');fig.savefig(P/'Fig7.png',dpi=250);plt.close(fig)
