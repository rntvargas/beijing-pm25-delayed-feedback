args <- commandArgs(trailingOnly=TRUE)
root <- if(length(args)) args[1] else 'outputs/06_factorial'
expected <- read.csv(file.path(root,'tables','factorial_metrics.csv'))
out <- list()
for(d in unique(expected$delay_h)) {
 z <- read.csv(gzfile(file.path(root,'predictions',paste0('factorial_',d,'h.csv.gz'))),check.names=FALSE)
 y <- z$target_pm25_24h
 for(i in which(expected$delay_h==d)) {
  e <- expected[i,];key <- paste(e$predictor,e$calibrator,sep='_');a<-1-e$nominal
  lo <- z[[paste0(key,'_lower_',sprintf('%.2f',e$nominal))]]
  hi <- z[[paste0(key,'_upper_',sprintf('%.2f',e$nominal))]]
  stopifnot(length(lo)==length(y),all(is.finite(lo)),all(hi>=lo))
  cover <- y>=lo & y<=hi
  calculated <- c(mean(cover),mean(hi-lo),mean(hi-lo+2/a*(pmax(lo-y,0)+pmax(y-hi,0))))
  err <- max(abs(calculated-as.numeric(e[,c('coverage','width','interval_score')])))
  stopifnot(err<1e-8,sum(cover)==e$covered_n)
  out[[length(out)+1]] <- data.frame(delay_h=d,predictor=e$predictor,calibrator=e$calibrator,nominal=e$nominal,max_difference=err)
 }
}
write.csv(do.call(rbind,out),file.path(root,'tables','verification_R.csv'),row.names=FALSE)
cat('PASS:',length(out),'factorial metric rows and exact coverage counts.\n')
