"""Recompute selected calibration quantiles and verify event-time ledgers."""
from pathlib import Path
import ast,json
import numpy as np
import pandas as pd
import joblib
from threadpoolctl import threadpool_limits
threadpool_limits(2)
ROOT=Path(__file__).resolve().parent;OLD=ROOT.parent/'03_experimento';DATA=ROOT.parent/'02_datos_estudio';SEED=20261005;panel=None
preds=json.loads((DATA/'manifest.json').read_text(encoding='utf8'))['predictors_allowlist']
tree=ast.parse((OLD/'experimento.py').read_text(encoding='utf8'))
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in {'Encoder','read','get_panel','delayed','clip','quantile','reference_predict','errors'}],type_ignores=[]),str(OLD/'experimento.py'),'exec'))
f=joblib.load(OLD/'models/fitted.joblib');c0=read('calibration');t0=read('test');checks=[];pointrows=[]
for delay in [0,6,24,72,168]:
 c=delayed(c0,delay);pc=clip(f['hgb'].predict(f['encoder'].transform(c)))
 t=pd.read_csv(ROOT/f'predictions/delay_{delay}h.csv.gz',parse_dates=['datetime','target_time','arrival_time','first_feedback_update'])
 assert (t.arrival_time==t.target_time+pd.Timedelta(hours=delay)).all()
 assert (t.first_feedback_update>=t.arrival_time).all()
 tt=delayed(t0,delay);predictions=reference_predict(tt,f['reference']);predictions.update(hgb=t.prediction_fixed.to_numpy(),ridge=clip(f['ridge'].predict(f['encoder'].transform(tt))))
 for name,p in predictions.items():
  for station,ix in tt.groupby('station').groups.items():pointrows.append({'delay_h':delay,'model':name,'station':station,'n':len(ix),**errors(tt.loc[ix,'target_pm25_24h'].to_numpy(),p[ix])})
 times=pd.concat([c.target_time,t.target_time],ignore_index=True)+pd.Timedelta(hours=delay)
 scores=np.r_[abs(c.target_pm25_24h.to_numpy()-pc),abs(t.target_pm25_24h.to_numpy()-t.prediction_fixed.to_numpy())]
 days=t.datetime.dt.floor('D');unique=days.unique();sample=unique[np.linspace(0,len(unique)-1,9).astype(int)]
 for day in sample:
  day=pd.Timestamp(day);eligible=(times<=day)&(times>day-pd.Timedelta(days=30));ix=np.flatnonzero(days.eq(day))
  for alpha in [.1,.05]:
   q=quantile(scores[eligible],alpha)
   np.testing.assert_allclose(t.loc[ix,f'rolling_global_upper_{1-alpha:.2f}'].to_numpy()-t.loc[ix,'prediction_fixed'].to_numpy(),q,rtol=0,atol=1e-8)
   # Counterfactual: changing every unavailable response cannot change the chosen quantile.
   changed=scores.copy();changed[~eligible]=1e12
   assert quantile(changed[eligible],alpha)==q
   checks.append({'delay_h':delay,'day':str(day),'nominal':1-alpha,'eligible':int(eligible.sum()),'quantile':q,'future_perturbation_invariant':True})
 ledger=pd.read_csv(ROOT/f'predictions/residual_event_ledger_{delay}h.csv.gz',parse_dates=['datetime','target_time','arrival','first_inclusion','last_possible_use'])
 assert (ledger.arrival==ledger.target_time+pd.Timedelta(hours=delay)).all()
 assert (ledger.first_inclusion>=ledger.arrival).all()
 assert (ledger.datetime<ledger.arrival).all()
pd.DataFrame(checks).to_csv(ROOT/'tables/verificacion_tiempos.csv',index=False)
pd.DataFrame(pointrows).to_csv(ROOT/'tables/original_point_metrics_by_station.csv',index=False)
audit=pd.read_csv(ROOT/'tables/fit_arrival_audit.csv')
assert (pd.to_datetime(audit.latest_label_arrival)<pd.to_datetime(audit.fit_cutoff)).all()
print('PASS:',len(checks),'calibration quantiles; future-response perturbations; full event ledgers; arrival-purged model fits.')
