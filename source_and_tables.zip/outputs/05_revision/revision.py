"""Exploratory extension. Run from Python 3.12 with ../03_experimento/requirements.txt."""
import os
os.environ.setdefault('OMP_NUM_THREADS','2')
os.environ.setdefault('OPENBLAS_NUM_THREADS','2')
from pathlib import Path
import ast,json,hashlib,time
import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingRegressor
from threadpoolctl import threadpool_limits
import joblib
ROOT=Path(__file__).resolve().parent;OLD=ROOT.parent/'03_experimento';DATA=ROOT.parent/'02_datos_estudio'
for x in ['tables','predictions','models']: (ROOT/x).mkdir(exist_ok=True)
SEED=20261005;threadpool_limits(2)
preds=json.loads((DATA/'manifest.json').read_text(encoding='utf8'))['predictors_allowlist']
panel=None
# Reuse unchanged, audited feature definitions without executing the old experiment.
tree=ast.parse((OLD/'experimento.py').read_text(encoding='utf8'))
names={'Encoder','read','get_panel','delayed','clip','errors','reference_fit','reference_predict','quantile'}
exec(compile(ast.Module(body=[x for x in tree.body if isinstance(x,(ast.FunctionDef,ast.ClassDef)) and x.name in names],type_ignores=[]),str(OLD/'experimento.py'),'exec'))
class SafeEncoder(Encoder):
 def fit(self,d):
  super().fit(d)
  self.keep=super().transform(d).columns[super().transform(d).notna().any()].tolist()
  return self
 def transform(self,d):
  z=super().transform(d)
  return z[self.keep] if hasattr(self,'keep') else z
def model(loss='absolute_error',leaves=15,q=None):
 return HistGradientBoostingRegressor(loss=loss,quantile=q,max_leaf_nodes=leaves,max_iter=100,learning_rate=.05,min_samples_leaf=40,l2_regularization=1,early_stopping=False,random_state=20261003)
def save(d,name):pd.DataFrame(d).to_csv(ROOT/'tables'/name,index=False)
def stats(y,l,u,alpha):
 w=u-l;c=(y>=l)&(y<=u);pen=2/alpha*(np.maximum(l-y,0)+np.maximum(y-u,0))
 return c,w,w+pen
def pack(t,p,l,u,alpha,method,delay):
 y=t.target_pm25_24h.to_numpy();c,w,s=stats(y,l,u,alpha)
 return {'delay_h':delay,'method':method,'nominal':1-alpha,'n':len(y),'coverage':c.mean(),'width':w.mean(),'interval_score':s.mean()}
def get_q(v,a):return quantile(v,a)
def rolling(c,t,pc,pt,delays,alpha,kind='global',adaptive=False):
 # Every archive row carries its own delivery delay; retrieval is by arrival, not measurement.
 z=pd.concat([c[['station','datetime','target_time','target_pm25_24h']],t[['station','datetime','target_time','target_pm25_24h']]],ignore_index=True)
 z['delay']=z.station.map(delays);z['arrival']=z.target_time+pd.to_timedelta(z.delay,unit='h')
 z['residual']=np.abs(z.target_pm25_24h.to_numpy()-np.r_[pc,pt]);z['source']=np.arange(len(z))
 qout=np.empty(len(t));ahat=np.empty(len(t));lo=np.full(len(t),np.nan);up=lo.copy();y=t.target_pm25_24h.to_numpy()
 ty=t.target_time+pd.to_timedelta(t.station.map(delays),unit='h');last=None;a=alpha;log=[];audit=[]
 for day,indices in t.groupby(t.datetime.dt.floor('D')).groups.items():
  ix=np.asarray(indices);arrived=(ty<=day)&(t.datetime<day)
  if last is not None:arrived&=ty>last
  ai=np.flatnonzero(arrived.to_numpy())
  if adaptive and len(ai):
   assert np.isfinite(lo[ai]).all()
   miss=np.mean((y[ai]<lo[ai])|(y[ai]>up[ai]));a=float(np.clip(a+.01*(alpha-miss),.001,.5))
  chosen=z[(z.arrival<=day)&(z.arrival>day-pd.Timedelta(days=30))]
  assert len(chosen) and (chosen.arrival<=day).all() and (chosen.datetime<day).all()
  if kind=='global':qout[ix]=get_q(chosen.residual.to_numpy(),a)
  elif kind=='station':
   for station in t.iloc[ix].station.unique():
    si=ix[t.iloc[ix].station.to_numpy()==station];v=chosen.loc[chosen.station.eq(station),'residual'].to_numpy();assert len(v)>100;qout[si]=get_q(v,a)
  else:
   v=chosen.sort_values('residual');weights=1/v.groupby('station').station.transform('size').to_numpy();cum=np.cumsum(weights)/weights.sum()
   qout[ix]=v.residual.iloc[min(np.searchsorted(cum,1-a),len(v)-1)]
  ahat[ix]=a;lo[ix]=np.maximum(0,pt[ix]-qout[ix]);up[ix]=pt[ix]+qout[ix]
  log.append({'day':day,'alpha':a,'feedback_n':len(ai),'residual_n':len(chosen),'max_arrival':chosen.arrival.max(),'method':kind+('_aci' if adaptive else ''),'nominal':1-alpha})
  # Full daily eligibility ledger: the actual calibration residual keys, not just selected examples.
  if not adaptive and kind=='global' and alpha==.1:
   lastrow=chosen.loc[chosen.arrival.idxmax()]
   audit.append({'calibration_time':day,'max_issue':chosen.datetime.max(),'max_target':chosen.target_time.max(),'max_arrival':chosen.arrival.max(),'n_residuals':len(chosen),'max_arrival_issue':lastrow.datetime,'max_arrival_target':lastrow.target_time,'max_arrival_station':lastrow.station})
  last=day
 return lo,up,log,audit

dev0=read('development');cal0=read('calibration');test0=read('test')
fixed=joblib.load(OLD/'models/fitted.joblib');enc=fixed['encoder'];base=fixed['hgb']
folds=[('2014-03-01','2014-07-01'),('2014-07-01','2014-11-01'),('2014-11-01','2015-03-01')]
metrics=[];points=[];cv=[];states=[];audits=[];cache={};fitlog=[]
for var,file in [('metrics','interval_metrics.csv'),('points','point_metrics.csv'),('cv','cv_adapted.csv'),('states','calibration_state.csv'),('audits','arrival_audit_daily.csv'),('fitlog','fit_arrival_audit.csv')]:
 if (ROOT/'tables'/file).exists():globals()[var]=pd.read_csv(ROOT/'tables'/file).to_dict('records')
for d in [0,6,24,72,168]:
 print('Preparing delay',d,flush=True)
 dev=delayed(dev0,d);c=delayed(cal0,d);t=delayed(test0,d);Xc=enc.transform(c);Xt=enc.transform(t)
 pc=clip(base.predict(Xc));pt=clip(base.predict(Xt));cache[d]=(c,t,pc,pt)
 if (ROOT/f'predictions/delay_{d}h.csv.gz').exists():
  print('Existing completed delay retained',d,flush=True);continue
 pred=t[['station','datetime','target_time','target_pm25_24h']].copy();pred['arrival_time']=t.target_time+pd.Timedelta(hours=d);pred['prediction_fixed']=pt
 pred['first_feedback_update']=pred.arrival_time.dt.ceil('D')
 assert (pred.first_feedback_update>=pred.arrival_time).all()
 # Explicitly arrival-purged model selection and final fit for experiment B.
 dscores=[]
 for leaf in [15,31]:
  for fold,(start,end) in enumerate(folds,1):
   tr=dev[dev.target_time.add(pd.Timedelta(hours=d)).lt(start)];va=dev[dev.datetime.ge(start)&dev.target_time.lt(end)]
   e=SafeEncoder().fit(tr);m=model(leaves=leaf);m.fit(e.transform(tr),tr.target_pm25_24h)
   row={'delay_h':d,'leaves':leaf,'fold':fold,**errors(va.target_pm25_24h.to_numpy(),clip(m.predict(e.transform(va)))),'n_train':len(tr),'n_val':len(va)};cv.append(row);dscores.append(row)
 best=int(pd.DataFrame(dscores).groupby('leaves').mae.mean().idxmin())
 train=dev[dev.target_time.add(pd.Timedelta(hours=d)).lt('2015-03-01')];e=SafeEncoder().fit(train);X=e.transform(train)
 fitted=model(leaves=best);fitted.fit(X,train.target_pm25_24h);pb=clip(fitted.predict(e.transform(t)));pred['prediction_adapted']=pb
 fitlog.append({'delay_h':d,'chosen_leaves':best,'n_train':len(train),'latest_label_arrival':str((train.target_time+pd.Timedelta(hours=d)).max()),'fit_cutoff':'2015-03-01'})
 for name,p in [('fixed_hgb',pt),('adapted_hgb',pb)]:
  points.append({'delay_h':d,'model':name,'group':'overall','value':'all','n':len(t),**errors(t.target_pm25_24h.to_numpy(),p)})
  for st,ix in t.groupby('station').groups.items():points.append({'delay_h':d,'model':name,'group':'station','value':st,'n':len(ix),**errors(t.loc[ix,'target_pm25_24h'].to_numpy(),p[ix])})
 joblib.dump({'encoder':e,'model':fitted},ROOT/f'models/adapted_{d}h.joblib')
 qc={};qt={}
 for q in [.025,.05,.95,.975]:
  qm=model(loss='quantile',q=q);qm.fit(X,train.target_pm25_24h);qc[q]=clip(qm.predict(e.transform(c)));qt[q]=clip(qm.predict(e.transform(t)))
  joblib.dump({'encoder':e,'model':qm},ROOT/f'models/quantile_{q}_{d}h.joblib')
 for alpha in [.1,.05]:
  ql,qh=alpha/2,1-alpha/2
  cl=np.minimum(qc[ql],qc[qh]);cu=np.maximum(qc[ql],qc[qh]);tl=np.minimum(qt[ql],qt[qh]);tu=np.maximum(qt[ql],qt[qh])
  scores=np.maximum(cl-c.target_pm25_24h.to_numpy(),c.target_pm25_24h.to_numpy()-cu)
  correction=get_q(scores[c.target_time.lt('2016-02-23')],alpha)
  assert correction>=0,'Negative CQR correction requires explicit empty-set handling'
  bounds={'quantile_raw':(tl,tu),'CQR_adapted':(np.maximum(0,tl-correction),tu+correction)}
  delays={s:d for s in t.station.unique()}
  for kind,adapt in [('global',False),('station',False),('equal_station',False),('global',True)]:
   l,u,logs,au=rolling(c,t,pc,pt,delays,alpha,kind,adapt);name='ACI_delayed_projected' if adapt else 'rolling_'+kind
   bounds[name]=(l,u);states.extend(dict(x,delay_h=d) for x in logs);audits.extend(dict(x,delay_h=d) for x in au)
  for name,(l,u) in bounds.items():
   metrics.append(pack(t,pt,l,u,alpha,name,d));pred[f'{name}_lower_{1-alpha:.2f}']=l;pred[f'{name}_upper_{1-alpha:.2f}']=u
 pred.to_csv(ROOT/f'predictions/delay_{d}h.csv.gz',index=False,compression={'method':'gzip','compresslevel':1,'mtime':0})
 save(metrics,'interval_metrics.csv');save(points,'point_metrics.csv');save(cv,'cv_adapted.csv');save(states,'calibration_state.csv');save(audits,'arrival_audit_daily.csv');save(fitlog,'fit_arrival_audit.csv')
 print('Finished delay',d, 'selected leaves',best,flush=True)

# Station-heterogeneous delays, using the same already fitted point predictor.
metrics=[row for row in metrics if str(row['delay_h'])!='station_heterogeneous']
stations=sorted(test0.station.unique());mapping={s:[6,24,72,168][i%4] for i,s in enumerate(stations)}
cs=[];ts=[];pcs=[];pts=[]
for s in stations:
 c,t,pc,pt=cache[mapping[s]];ci=c.station.eq(s).to_numpy();ti=t.station.eq(s).to_numpy();cs.append(c[ci]);ts.append(t[ti]);pcs.append(pc[ci]);pts.append(pt[ti])
c=pd.concat(cs,ignore_index=True);t=pd.concat(ts,ignore_index=True);pc=np.concatenate(pcs);pt=np.concatenate(pts)
pred=t[['station','datetime','target_time','target_pm25_24h']].copy();pred['delay_h']=t.station.map(mapping);pred['arrival_time']=t.target_time+pd.to_timedelta(pred.delay_h,unit='h');pred['prediction']=pt
for alpha in [.1,.05]:
 for kind,adapt in [('global',False),('station',False),('equal_station',False),('global',True)]:
  l,u,logs,au=rolling(c,t,pc,pt,mapping,alpha,kind,adapt);name='ACI_delayed_projected' if adapt else 'rolling_'+kind
  metrics.append(pack(t,pt,l,u,alpha,name,'station_heterogeneous'));pred[f'{name}_lower_{1-alpha:.2f}']=l;pred[f'{name}_upper_{1-alpha:.2f}']=u
pred.to_csv(ROOT/'predictions/station_heterogeneous.csv.gz',index=False,compression='gzip')
save(metrics,'interval_metrics.csv');save([{'station':s,'delay_h':d} for s,d in mapping.items()],'station_delay_mapping.csv')
(ROOT/'RUN_MANIFEST.json').write_text(json.dumps({'status':'complete','analysis':'post-review exploratory extension','seed':SEED,'protocol_sha256':hashlib.sha256((ROOT/'PROTOCOLO_AMPLIACION.md').read_bytes()).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'ACI':'daily batched projected variant; not the unmodified algorithm or its theorem','external_validation':False},indent=2),encoding='utf8')
print('ALL MODEL EXPERIMENTS COMPLETE',flush=True)
