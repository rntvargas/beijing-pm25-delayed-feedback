# Registro actualizado

Las declaraciones personales previamente pendientes fueron confirmadas. Véase DECLARACIONES_CONFIRMADAS.md. La selección de revista y sus requisitos editoriales específicos continúan pendientes.
