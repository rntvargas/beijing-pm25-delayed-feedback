# Implementation amendments

Entirely unobserved training columns are dropped using training data only to avoid a numerical binning failure; no test-based feature selection is performed.

The earlier temporal sensitivity uses a fixed 15-leaf model and training labels arriving before January 2014. This was added after the extension began; it is explicitly exploratory and not independent confirmation.

The original analysis and the extension use separate bootstrap random streams. Original primary intervals remain unchanged in the manuscript; extension intervals are separately tabulated.
