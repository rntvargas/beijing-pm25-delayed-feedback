"""Block uncertainty, missingness and decision-oriented diagnostics. No model tuning."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits
threadpool_limits(2)
R=Path(__file__).resolve().parent;O=R.parent/'03_experimento';D=R.parent/'02_datos_estudio';T=R/'tables';T.mkdir(exist_ok=True)
def save(x,n):pd.DataFrame(x).to_csv(T/n,index=False)
def values(y,l,u,a):return (y>=l)&(y<=u),u-l,(u-l)+2/a*(np.maximum(l-y,0)+np.maximum(y-u,0))
def weights(N,L):
 rng=np.random.default_rng(20261005+L);W=np.zeros((1000,N),dtype=np.int16)
 for b in range(1000):
  ix=((rng.integers(N,size=int(np.ceil(N/L)))[:,None]+np.arange(L))%N).ravel()[:N];W[b]=np.bincount(ix,minlength=N)
 return W
unc=[];sub=[];util=[];daysout=[];concs=[];costs=[]
dev=pd.read_csv(D/'data/development_24h.csv.gz',usecols=['target_pm25_24h']);cuts=np.r_[-np.inf,dev.target_pm25_24h.quantile([.25,.5,.75,.9]).to_numpy(),np.inf]
for d in [0,6,24,72,168]:
 z=pd.read_csv(O/f'predictions/delay_{d}h.csv.gz',parse_dates=['datetime','target_time'])
 new=R/f'predictions/delay_{d}h.csv.gz'
 if new.exists():
  n=pd.read_csv(new,parse_dates=['datetime','target_time']);assert (z.station==n.station).all() and (z.datetime==n.datetime).all()
  for c in n:
   if '_lower_' in c or '_upper_' in c:z[c]=n[c]
 y=z.target_pm25_24h.to_numpy();day=z.datetime.dt.floor('D');unique=pd.date_range(day.min(),day.max());daycode=unique.get_indexer(day);N=len(unique);Ws={L:weights(N,L) for L in [7,14,28]};counts=np.bincount(daycode,minlength=N)
 for a in [.1,.05]:
  level=f'{1-a:.2f}';methods=sorted(c[:-len('_lower_'+level)] for c in z if c.endswith('_lower_'+level) and 'DIAGNOSTIC' not in c)
  base=values(y,z[f'static_unmatched_lower_{level}'].to_numpy(),z[f'static_unmatched_upper_{level}'].to_numpy(),a)
  for method in methods:
   l=z[f'{method}_lower_{level}'].to_numpy();u=z[f'{method}_upper_{level}'].to_numpy();cover,w,score=values(y,l,u,a)
   matrix=np.column_stack([cover.astype(float),cover.astype(float)-base[0].astype(float),score-base[2]])
   sums=np.array([np.bincount(daycode,weights=matrix[:,j],minlength=N) for j in range(3)]).T
   point=matrix.mean(axis=0)
   for L,W in Ws.items():
    B=(W@sums)/(W@counts)[:,None]
    for j,metric in enumerate(['coverage','coverage_difference_vs_static','score_difference_vs_static']):
     low,high=np.quantile(B[:,j],[.025,.975]);unc.append({'delay_h':d,'nominal':1-a,'method':method,'metric':metric,'block_days':L,'estimate':point[j],'lower95':low,'upper95':high,'n':len(z)})
   if d==72:
    for group,labels in [('station',z.station),('quarter',z.datetime.dt.to_period('Q').astype(str))]:
     cats=sorted(labels.unique());ns=[];ds=[];est=[]
     for cat in cats:
      mask=(labels==cat).to_numpy();ns.append(np.bincount(daycode[mask],minlength=N));ds.append(np.bincount(daycode[mask],weights=matrix[mask,1],minlength=N));est.append(matrix[mask,1].mean())
     ns=np.array(ns).T;ds=np.array(ds).T;est=np.array(est)
     for L,W in Ws.items():
      den=W@ns;good=(den>0).all(axis=1);boot=(W[good]@ds)/den[good];rad=np.quantile(np.max(abs(boot-est),axis=1),.95)
      for j,cat in enumerate(cats):
       low,high=np.quantile(boot[:,j],[.025,.975]);sub.append({'method':method,'nominal':1-a,'group':group,'value':cat,'block_days':L,'coverage_diff':est[j],'pointwise_low':low,'pointwise_high':high,'simultaneous_low':max(-1,est[j]-rad),'simultaneous_high':min(1,est[j]+rad),'bootstrap_valid':int(good.sum())})
   if method=='rolling_valid':
    diff=score-base[2];daily=np.bincount(daycode,weights=diff,minlength=N)/counts
    util.append({'delay_h':d,'nominal':1-a,'days':N,'fraction_days_improved':np.mean(daily<0),'fraction_wider':np.mean(w>base[1]),'gained_covered':int((cover&~base[0]).sum()),'lost_covered':int((~cover&base[0]).sum()),'net_covered':int(cover.sum()-base[0].sum()),'mean_width_difference':np.mean(w-base[1]),'mean_penalty_difference':np.mean((score-w)-(base[2]-base[1])),'mean_score_difference':diff.mean(),'daily_q05':np.quantile(daily,.05),'daily_median':np.median(daily),'daily_q95':np.quantile(daily,.95)})
    daysout.extend({'delay_h':d,'nominal':1-a,'day':str(dd.date()),'score_difference':v,'n':cnt} for dd,v,cnt in zip(unique,daily,counts))
    for k in range(len(cuts)-1):
     mask=(y>cuts[k])&(y<=cuts[k+1]);concs.append({'delay_h':d,'nominal':1-a,'lower':cuts[k],'upper':cuts[k+1],'n':int(mask.sum()),'static_coverage':base[0][mask].mean(),'rolling_coverage':cover[mask].mean(),'score_difference':diff[mask].mean()})
    for penalty in [5,10,20,40,80]:
     costs.append({'delay_h':d,'nominal':1-a,'outside_distance_multiplier':penalty,'mean_loss_difference':np.mean(w-base[1]+penalty*a/2*((score-w)-(base[2]-base[1]))),'interpretation':'hypothetical width plus distance-outside cost, not monetary utility'})
 print('Bootstrap complete',d,flush=True)
save(unc,'coverage_and_score_bootstrap.csv');save(sub,'subgroup_simultaneous_bands.csv');save(util,'practical_utility.csv');save(daysout,'daily_practical_differences.csv');save(concs,'concentration_strata.csv')
save(costs,'hypothetical_cost_sensitivity.csv')

p=pd.read_csv(D/'data/panel_preservado.csv.gz',parse_dates=['datetime'])
p['missing']=p['PM2.5'].isna();p['month']=p.datetime.dt.month;p['hour']=p.datetime.dt.hour;p['year_month']=p.datetime.dt.to_period('M').astype(str)
p['study_period']=np.select([p.datetime.lt('2015-03-01'),p.datetime.lt('2016-03-01')],['development','calibration'],default='test')
miss=[]
for g in ['station','month','hour','year_month','study_period']:
 for key,v in p.groupby(g):miss.append({'group':g,'value':str(key),'n':len(v),'missing_n':int(v.missing.sum()),'missing_rate':v.missing.mean()})
for variable in ['PM10','NO2','TEMP','PRES','WSPM']:
 q=np.unique(p.loc[p.study_period.eq('development'),variable].dropna().quantile([.2,.4,.6,.8]).to_numpy());bins=np.r_[-np.inf,q,np.inf];labels=pd.cut(p[variable],bins).astype(str)
 for key,v in p.groupby(labels):miss.append({'group':variable+'_development_quintiles','value':str(key),'n':len(v),'missing_n':int(v.missing.sum()),'missing_rate':v.missing.mean()})
save(miss,'missingness_patterns.csv')
# Event ledger includes calibration and test forecast origins and bounds on daily use.
c=pd.read_csv(D/'data/calibration_24h.csv.gz',usecols=['station','datetime','target_time'],parse_dates=['datetime','target_time'])
t=pd.read_csv(D/'data/test_24h.csv.gz',usecols=['station','datetime','target_time'],parse_dates=['datetime','target_time'])
z=pd.concat([c.assign(period='calibration'),t.assign(period='test')],ignore_index=True)
for delay in [0,6,24,72,168]:
 ledger=z.copy();ledger['delay_h']=delay;ledger['arrival']=ledger.target_time+pd.Timedelta(hours=delay)
 ledger['first_inclusion']=ledger.arrival.dt.ceil('D').clip(lower=t.datetime.min().floor('D'))
 ledger['last_possible_use']=(ledger.arrival+pd.Timedelta(days=30)-pd.Timedelta(nanoseconds=1)).dt.floor('D').clip(upper=t.datetime.max().floor('D'))
 ledger['used_in_test_rolling']=ledger.first_inclusion.le(ledger.last_possible_use)
 assert (ledger.first_inclusion>=ledger.arrival).all()
 ledger.to_csv(R/f'predictions/residual_event_ledger_{delay}h.csv.gz',index=False,compression='gzip')
print('DIAGNOSTICS COMPLETE',flush=True)
