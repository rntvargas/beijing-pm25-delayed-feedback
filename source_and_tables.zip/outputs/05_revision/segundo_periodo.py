"""Earlier temporal sensitivity; same city, not an independent external replication."""
import os
os.environ.setdefault('OMP_NUM_THREADS','2')
from pathlib import Path
import ast,json
import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingRegressor
from threadpoolctl import threadpool_limits
threadpool_limits(2)
ROOT=Path(__file__).resolve().parent;OLD=ROOT.parent/'03_experimento';DATA=ROOT.parent/'02_datos_estudio';SEED=20261005;panel=None
preds=json.loads((DATA/'manifest.json').read_text(encoding='utf8'))['predictors_allowlist']
for filename,names in [(OLD/'experimento.py',{'Encoder','read','get_panel','delayed','clip','errors','quantile'}),(ROOT/'revision.py',{'SafeEncoder','model','get_q','stats','pack','rolling'})]:
 tree=ast.parse(filename.read_text(encoding='utf8'));exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in names],type_ignores=[]),str(filename),'exec'))
d=72;dev=delayed(read('development'),d);t=delayed(read('calibration'),d)
train=dev[(dev.target_time+pd.Timedelta(hours=d)).lt('2014-01-01')];c=dev[dev.datetime.ge('2014-01-01') & dev.target_time.lt('2015-02-22')].reset_index(drop=True)
assert (train.target_time+pd.Timedelta(hours=d)).max()<pd.Timestamp('2014-01-01')
e=SafeEncoder().fit(train);X=e.transform(train);Xc=e.transform(c);Xt=e.transform(t);f=model();f.fit(X,train.target_pm25_24h);pc=clip(f.predict(Xc));pt=clip(f.predict(Xt))
alpha=.1;res=abs(c.target_pm25_24h.to_numpy()-pc);q=quantile(res,alpha);bounds={'static_matched':(np.maximum(0,pt-q),pt+q)}
mapping={s:d for s in t.station.unique()}
for kind,adapt in [('global',False),('global',True)]:
 l,u,_,_=rolling(c,t,pc,pt,mapping,alpha,kind,adapt);bounds['ACI_delayed_projected' if adapt else 'rolling_global']=(l,u)
cp=[];tp=[]
for quant in [.05,.95]:
 f=model(loss='quantile',q=quant);f.fit(X,train.target_pm25_24h);cp.append(clip(f.predict(Xc)));tp.append(clip(f.predict(Xt)))
cl,cu=np.minimum(*cp),np.maximum(*cp);tl,tu=np.minimum(*tp),np.maximum(*tp);q=quantile(np.maximum(cl-c.target_pm25_24h.to_numpy(),c.target_pm25_24h.to_numpy()-cu),alpha);assert q>=0
bounds['CQR_adapted']=(np.maximum(0,tl-q),tu+q)
pred=t[['station','datetime','target_time','target_pm25_24h']].copy();rows=[]
for name,(l,u) in bounds.items():
 rows.append(dict(pack(t,pt,l,u,alpha,name,d),period='2015-03_to_2016-02',training_n=len(train),calibration_n=len(c)))
 pred[name+'_lower_0.90']=l;pred[name+'_upper_0.90']=u
pd.DataFrame(rows).to_csv(ROOT/'tables/second_period_metrics.csv',index=False)
pred.to_csv(ROOT/'predictions/second_period.csv.gz',index=False,compression='gzip')
print(pd.DataFrame(rows).to_string(index=False),flush=True)
