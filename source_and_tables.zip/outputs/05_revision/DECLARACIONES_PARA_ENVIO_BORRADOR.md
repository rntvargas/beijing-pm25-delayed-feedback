# Declaraciones actualizadas

Este borrador queda sustituido por las declaraciones de manuscript.tex y el registro DECLARACIONES_CONFIRMADAS.md. La confirmación del autor fue incorporada el 6 de octubre de 2026.
