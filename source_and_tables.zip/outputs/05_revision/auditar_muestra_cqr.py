"""Additional editorial audit; does not alter archived models or predictions."""
from pathlib import Path
import ast,json,hashlib
import numpy as np
import pandas as pd
import joblib
from threadpoolctl import threadpool_limits
threadpool_limits(2)
ROOT=Path(__file__).resolve().parent;OLD=ROOT.parent/'03_experimento';DATA=ROOT.parent/'02_datos_estudio';SEED=20261005;panel=None
preds=json.loads((DATA/'manifest.json').read_text(encoding='utf8'))['predictors_allowlist']
tree=ast.parse((OLD/'experimento.py').read_text(encoding='utf8'))
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in {'Encoder','read','get_panel','delayed','clip'}],type_ignores=[]),str(OLD/'experimento.py'),'exec'))
tree=ast.parse((ROOT/'revision.py').read_text(encoding='utf8'))
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='SafeEncoder'],type_ignores=[]),str(ROOT/'revision.py'),'exec'))
base=read('calibration');test=read('test');mask=base.target_time.lt('2016-02-23');rows=[]
keys=base.loc[mask,['station','datetime','target_time']].to_csv(index=False,lineterminator='\n').encode();key_hash=hashlib.sha256(keys).hexdigest()
for delay in [0,6,24,72,168]:
 c=delayed(base,delay);assert len(c)==len(base)
 assert c[['station','datetime','target_time']].equals(base[['station','datetime','target_time']])
 assert set(preds).issubset(c.columns) and c.target_pm25_24h.notna().all()
 for q in [.025,.05,.95,.975]:
  obj=joblib.load(ROOT/f'models/quantile_{q}_{delay}h.joblib');e=obj['encoder'];X=e.transform(c);p=obj['model'].predict(X)
  assert len(X)==len(base) and np.isfinite(p).all()
  keep=getattr(e,'keep',e.cols)
  removed=sorted(set(e.cols)-set(keep));last=(c.loc[mask,'target_time']+pd.Timedelta(hours=delay)).max()
  assert last<test.datetime.min()
  rows.append(dict(delay_h=delay,quantile=q,calibration_base_n=len(base),after_common_cutoff_n=int(mask.sum()),excluded_by_cutoff_n=int((~mask).sum()),rows_dropped_for_predictor_missingness=0,required_source_columns=len(preds),encoded_columns_before_filter=len(e.cols),encoded_columns_used=len(keep),training_only_removed_columns=';'.join(removed),calibration_rows_with_any_missing_predictor=int(X.loc[mask].isna().any(axis=1).sum()),calibration_keys_sha256=key_hash,latest_target=str(c.loc[mask,'target_time'].max()),latest_arrival=str(last),first_test_issue=str(test.datetime.min()),finite_predictions=True))
 print('Audited CQR sample/columns:',delay,flush=True)
pd.DataFrame(rows).to_csv(ROOT/'tables/cqr_sample_and_features_audit.csv',index=False)
print('PASS: 20 quantile learners, 10 interval configurations, identical observed calibration keys.')
