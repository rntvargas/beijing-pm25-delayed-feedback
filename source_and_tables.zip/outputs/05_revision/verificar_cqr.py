"""Reconstruct the executed CQR algorithm from saved quantile models.

Audits ordering/clipping, finite-sample rank, common cutoff, arrival eligibility,
and every stored main-period CQR endpoint. No model refitting or tuning.
"""
from pathlib import Path
import ast,json
import numpy as np
import pandas as pd
import joblib
from threadpoolctl import threadpool_limits
threadpool_limits(2)
SEED=20261005
ROOT=Path(__file__).resolve().parent;OLD=ROOT.parent/'03_experimento';DATA=ROOT.parent/'02_datos_estudio';panel=None
preds=json.loads((DATA/'manifest.json').read_text(encoding='utf8'))['predictors_allowlist']
tree=ast.parse((OLD/'experimento.py').read_text(encoding='utf8'))
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in {'Encoder','read','get_panel','delayed','clip'}],type_ignores=[]),str(OLD/'experimento.py'),'exec'))
tree=ast.parse((ROOT/'revision.py').read_text(encoding='utf8'))
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='SafeEncoder'],type_ignores=[]),str(ROOT/'revision.py'),'exec'))
cal0=read('calibration');test0=read('test');rows=[]
for d in [0,6,24,72,168]:
 c=delayed(cal0,d);t=delayed(test0,d);stored=pd.read_csv(ROOT/f'predictions/delay_{d}h.csv.gz')
 assert np.array_equal(t.station,stored.station)
 assert np.array_equal(t.datetime.to_numpy(),pd.to_datetime(stored.datetime).to_numpy())
 qc={};qt={}
 for q in [.025,.05,.95,.975]:
  obj=joblib.load(ROOT/f'models/quantile_{q}_{d}h.joblib')
  qc[q]=np.maximum(0,obj['model'].predict(obj['encoder'].transform(c)))
  qt[q]=np.maximum(0,obj['model'].predict(obj['encoder'].transform(t)))
 for alpha in [.1,.05]:
  lq,uq=alpha/2,1-alpha/2
  lo=np.minimum(qc[lq],qc[uq]);up=np.maximum(qc[lq],qc[uq]);scores=np.maximum(lo-c.target_pm25_24h.to_numpy(),c.target_pm25_24h.to_numpy()-up)
  mask=c.target_time.lt('2016-02-23');v=scores[mask];n=len(v);k=int(np.ceil((n+1)*(1-alpha)))
  assert 1<=k<=n
  q=float(np.sort(v)[k-1]);assert q>=0
  arrivals=c.loc[mask,'target_time']+pd.Timedelta(hours=d);assert arrivals.max()<t.datetime.min()
  low=np.maximum(0,np.minimum(qt[lq],qt[uq])-q);high=np.maximum(qt[lq],qt[uq])+q
  error=max(np.max(abs(low-stored[f'CQR_adapted_lower_{1-alpha:.2f}'])),np.max(abs(high-stored[f'CQR_adapted_upper_{1-alpha:.2f}'])))
  assert error<1e-8
  rows.append(dict(delay_h=d,nominal=1-alpha,n_calibration=n,rank=k,correction=q,negative_score_fraction=np.mean(v<0),calibration_crossings=int((qc[lq]>qc[uq]).sum()),test_crossings=int((qt[lq]>qt[uq]).sum()),latest_calibration_arrival=str(arrivals.max()),first_test_issue=str(t.datetime.min()),max_endpoint_error=error))
 print('CQR reconstructed:',d,flush=True)
pd.DataFrame(rows).to_csv(ROOT/'tables/cqr_algorithm_audit.csv',index=False)
print('PASS: all 10 CQR configurations and all saved main-period interval endpoints.')
