# Independently recompute every reported interval metric from saved bounds.
args <- commandArgs(trailingOnly=TRUE)
root <- if(length(args)) args[1] else "."
expected <- read.csv(file.path(root,"tables","interval_metrics.csv"),check.names=FALSE)
checks <- list()
for(delay in unique(expected$delay_h)) {
 name <- if(delay == "station_heterogeneous") "station_heterogeneous.csv.gz" else paste0("delay_",delay,"h.csv.gz")
 d <- read.csv(gzfile(file.path(root,"predictions",name)),check.names=FALSE)
 y <- d$target_pm25_24h
 for(i in which(expected$delay_h==delay)) {
  e <- expected[i,];a <- 1-e$nominal
  l <- d[[paste0(e$method,"_lower_",sprintf("%.2f",e$nominal))]]
  u <- d[[paste0(e$method,"_upper_",sprintf("%.2f",e$nominal))]]
  stopifnot(length(l)==length(y),all(is.finite(l)),all(is.finite(u)),all(u>=l))
  v <- c(mean(y>=l & y<=u),mean(u-l),mean(u-l+2/a*(pmax(l-y,0)+pmax(y-u,0))))
  err <- max(abs(v-as.numeric(e[,c("coverage","width","interval_score")])))
  stopifnot(err<1e-8)
  checks[[length(checks)+1]] <- data.frame(delay=delay,method=e$method,nominal=e$nominal,max_absolute_difference=err)
 }
}
write.csv(do.call(rbind,checks),file.path(root,"tables","verificacion_R_revision.csv"),row.names=FALSE)
cat("PASS: ",length(checks)," rows independently recomputed in R.\n")
