"""Post-review paired score contrasts, conditional on stored fitted pipelines.

10,000 circular day-block draws, 7/14/28 days; all stations kept together.
Percentile pointwise intervals, no selection/refitting or multiplicity guarantee.
Legacy prediction keys are retained to preserve the v0.2.0 computational record.
"""
from pathlib import Path
import hashlib,json
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits
threadpool_limits(2)
R=Path(__file__).resolve().parent; O=R.parent/'03_experimento'; B=10000; SEED=20261006
LABEL={'ACI_delayed_projected':'ACI-inspired daily delayed-feedback heuristic (ADH)',
       'CQR_adapted':'CQR with delay-specific training','rolling_valid':'Rolling valid',
       'rolling_global':'Rolling valid'}
def score(y,l,u,a):return u-l+2/a*(np.maximum(l-y,0)+np.maximum(y-u,0))
def weights(n,L):
 rng=np.random.default_rng(SEED+L);w=np.zeros((B,n),dtype=np.int16)
 for b in range(B):
  ix=((rng.integers(n,size=int(np.ceil(n/L)))[:,None]+np.arange(L))%n).ravel()[:n]
  w[b]=np.bincount(ix,minlength=n)
 return w
rows=[];daily=[];inputs={}
def process(z,scenario,delay,levels,pairs):
 day=pd.to_datetime(z.datetime).dt.floor('D');days=pd.date_range(day.min(),day.max());code=days.get_indexer(day)
 counts=np.bincount(code,minlength=len(days));ws={L:weights(len(days),L) for L in [7,14,28]}
 y=z.target_pm25_24h.to_numpy()
 for nominal in levels:
  a=1-nominal; lev=f'{nominal:.2f}'; scores={}
  for left,right in pairs:
   for method in [left,right]:
    if method not in scores:
     l=z[f'{method}_lower_{lev}'].to_numpy();u=z[f'{method}_upper_{lev}'].to_numpy()
     assert np.isfinite(l).all() and np.isfinite(u).all() and (l<=u).all()
     scores[method]=score(y,l,u,a)
   difference=scores[left]-scores[right];sums=np.bincount(code,weights=difference,minlength=len(days))
   point=difference.mean();np.testing.assert_allclose(sums.sum()/counts.sum(),point,rtol=0,atol=1e-10)
   for d,ss,nn in zip(days,sums,counts):
    daily.append(dict(scenario=scenario,delay_h=delay,nominal=nominal,left=left,right=right,day=str(d.date()),difference_sum=ss,n=int(nn)))
   for L,w in ws.items():
    vals=(w@sums)/(w@counts);low,high=np.quantile(vals,[.025,.975])
    rows.append(dict(scenario=scenario,delay_h=delay,nominal=nominal,left=left,right=right,left_label=LABEL.get(left,left),right_label=LABEL.get(right,right),block_days=L,estimate=point,lower95=low,upper95=high,replicates=B,seed=SEED+L,n=len(z),origin_days=len(days),interval_type='pointwise percentile, conditional on fitted models'))
def read(path):
 inputs[str(path.relative_to(R.parent))]=hashlib.sha256(path.read_bytes()).hexdigest()
 return pd.read_csv(path)
for d in [0,6,24,72,168]:
 z=read(R/f'predictions/delay_{d}h.csv.gz');old=read(O/f'predictions/delay_{d}h.csv.gz')
 assert z[['station','datetime','target_time']].equals(old[['station','datetime','target_time']])
 np.testing.assert_array_equal(z.target_pm25_24h,old.target_pm25_24h)
 for c in old:
  if c not in z and ('_lower_' in c or '_upper_' in c):z[c]=old[c]
 pairs=[('CQR_adapted','rolling_valid'),('ACI_delayed_projected','rolling_valid'),('CQR_adapted','ACI_delayed_projected'),('CQR_adapted','quantile_raw')]
 pairs += [(m,b) for m in ['CQR_adapted','ACI_delayed_projected'] for b in ['static_unmatched','static_matched']]
 process(z,'exploratory_main',d,[.9,.95],pairs);print('Paired bootstrap:',d,flush=True)
process(read(R/'predictions/second_period.csv.gz'),'sensitivity_earlier_period',72,[.9],[('CQR_adapted','rolling_global'),('ACI_delayed_projected','rolling_global'),('CQR_adapted','ACI_delayed_projected')])
process(read(R/'predictions/station_heterogeneous.csv.gz'),'sensitivity_heterogeneous','heterogeneous',[.9,.95],[('ACI_delayed_projected','rolling_global'),('rolling_station','rolling_global'),('rolling_equal_station','rolling_global')])
pd.DataFrame(rows).to_csv(R/'tables/exploratory_score_contrasts.csv',index=False)
pd.DataFrame(daily).to_csv(R/'tables/exploratory_score_daily_sums.csv',index=False)
(R/'EXPLORATORY_BOOTSTRAP_MANIFEST.json').write_text(json.dumps({'status':'complete','replicates':B,'base_seed':SEED,'block_days':[7,14,28],'analysis_status':'post-review exploratory; no refitting; pointwise intervals','input_sha256':inputs,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'contrast_interval_rows':len(rows)},indent=2),encoding='utf8')
print('COMPLETE',len(rows),'contrast-interval rows',flush=True)
